// sw.js — service worker minimal : l'application s'installe et les pages déjà visitées
// restent ouvertes hors connexion. Les appels à Supabase (données, PDF) ne sont JAMAIS mis en cache.
const CACHE = 'unim-v2';
const COQUILLE = ['index.html', 'connexion.html', 'inscription.html', 'css/style.css', 'icons/icon-192.png'];

self.addEventListener('install', (e) => {
    e.waitUntil(caches.open(CACHE).then((c) => c.addAll(COQUILLE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
    e.waitUntil(
        caches.keys()
            .then((noms) => Promise.all(noms.filter((n) => n !== CACHE).map((n) => caches.delete(n))))
            .then(() => self.clients.claim())
    );
});

self.addEventListener('fetch', (e) => {
    const req = e.request;
    if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return; // Supabase, esm.sh... : réseau direct

    // Réseau d'abord (toujours la dernière version), cache en secours
    e.respondWith(
        fetch(req)
            .then((rep) => {
                if (rep.ok) { const copie = rep.clone(); caches.open(CACHE).then((c) => c.put(req, copie)); }
                return rep;
            })
            .catch(() => caches.match(req))
    );
});
