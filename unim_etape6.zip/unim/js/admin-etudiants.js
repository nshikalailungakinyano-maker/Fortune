import { supabase } from './supabaseClient.js';
import { demarrerAdmin } from './admin-ui.js';
import { esc, afficherMessage } from './utils.js';
import { nomComplet, avatarHtml, toast } from './tfc-ui.js';

const ctx = await demarrerAdmin('etudiants');
if (ctx) {
    const moi = ctx.session.user.id;
    const etat = document.getElementById('etat');
    const liste = document.getElementById('liste');
    const recherche = document.getElementById('recherche');
    let etudiants = [];

    const { data, error } = await supabase.from('etudiants').select('*').order('date_creation', { ascending: false }).limit(1000);
    if (error) afficherMessage(etat, 'Erreur : ' + error.message, 'erreur');
    else { etudiants = data; rendre(); }

    function rendre() {
        const q = recherche.value.trim().toLowerCase();
        const vus = etudiants.filter((e) => !q || [e.nom, e.postnom, e.prenom, e.matricule, e.email, e.faculte].join(' ').toLowerCase().includes(q));
        afficherMessage(etat, vus.length ? `${vus.length} étudiant${vus.length > 1 ? 's' : ''}` : 'Aucun étudiant trouvé.', 'info');
        liste.innerHTML = vus.map((e) => {
            const actif = e.est_actif !== false;
            const peutAgir = e.role !== 'proprietaire' && e.id !== moi;
            return `<article class="carte ligne-tfc" data-id="${esc(e.id)}">
                <div class="ligne-haut"><div style="display:flex;gap:.7rem;align-items:center">${avatarHtml(e)}
                    <div><strong>${esc(nomComplet(e))}</strong><div class="meta-ligne" style="margin:0">${esc(e.email)}</div></div></div>
                    <span class="badge ${actif ? 'publie' : 'signale'}">${e.role === 'proprietaire' ? 'Propriétaire' : (actif ? 'Actif' : 'Suspendu')}</span></div>
                <p class="meta-ligne">Matricule : ${esc(e.matricule || '—')} · ${esc(e.faculte || '—')} · ${esc(e.promotion || '—')} · inscrit le ${esc(new Date(e.date_creation).toLocaleDateString('fr-FR'))}</p>
                ${peutAgir ? `<button type="button" class="btn btn-petit ${actif ? 'btn-danger' : ''}" data-act="actif" data-valeur="${actif ? 'non' : 'oui'}">${actif ? 'Suspendre le compte' : 'Réactiver le compte'}</button>` : ''}
            </article>`;
        }).join('');
    }

    recherche.addEventListener('input', rendre);

    liste.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-act="actif"]');
        if (!b) return;
        const id = b.closest('article').dataset.id;
        const activer = b.dataset.valeur === 'oui';
        if (!confirm(activer ? 'Réactiver ce compte ?' : 'Suspendre ce compte ? L\'étudiant ne pourra plus déposer ni commenter.')) return;
        const { error } = await supabase.rpc('proprietaire_definir_actif', { p_etudiant: id, p_actif: activer });
        if (error) return toast('Action impossible : ' + error.message);
        etudiants = etudiants.map((x) => (x.id === id ? { ...x, est_actif: activer } : x));
        rendre();
    });
}
