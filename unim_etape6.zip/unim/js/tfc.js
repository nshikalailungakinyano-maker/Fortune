import { supabase } from './supabaseClient.js';
import { getSession } from './auth.js';
import { monterEntete } from './layout.js';
import { carteTfc, brancherActions, chargerAuteurs, mesLikes, estUuid, avatarHtml, nomComplet, dateRelative, toast } from './tfc-ui.js';
import { afficherMessage, esc } from './utils.js';

monterEntete('bibliotheque');
const etat = document.getElementById('etat');
const id = new URLSearchParams(location.search).get('id');
const session = await getSession();
const moi = session?.user.id ?? null;

const { data: tfc, error } = estUuid(id)
    ? await supabase.from('tfc').select('*, likes_tfc(count), commentaires(count)').eq('id', id).maybeSingle()
    : { data: null, error: null };

if (error || !tfc) {
    afficherMessage(etat, "TFC introuvable ou non publié.", 'erreur');
} else {
    document.title = tfc.titre + ' — UNIM';
    const [auteurs, aimes] = await Promise.all([chargerAuteurs([tfc.etudiant_id]), mesLikes(moi, [tfc.id])]);
    const post = document.getElementById('post');
    post.innerHTML = carteTfc(tfc, auteurs.get(tfc.etudiant_id), { aime: aimes.has(tfc.id), detail: true });
    brancherActions(post, moi);

    // Signalement (transmis au propriétaire ; il décide de la suite, le TFC reste visible entre-temps)
    if (moi && tfc.statut === 'publie' && tfc.etudiant_id !== moi) {
        post.insertAdjacentHTML('beforeend', '<p class="aide"><button type="button" id="btnSignaler" class="lien">Signaler ce TFC</button></p>');
        document.getElementById('btnSignaler').addEventListener('click', async () => {
            const motif = prompt('Motif du signalement (plagiat, contenu inapproprié, informations erronées...) :');
            if (motif === null) return;
            const { error } = await supabase.rpc('signaler_tfc', { p_tfc: tfc.id, p_motif: motif });
            toast(error ? 'Signalement impossible : ' + error.message : 'Merci, votre signalement a été transmis au propriétaire.');
        });
    }
    document.getElementById('commentaires').hidden = false;
    await chargerCommentaires();
    if (location.hash === '#commentaires') document.getElementById('commentaires').scrollIntoView();
}

// ---------- Commentaires
const liste = document.getElementById('listeCommentaires');
const saisie = document.getElementById('zoneSaisie');

function htmlCommentaire(c, a) {
    const proprio = c.etudiant_id === moi;
    const nom = proprio && !a ? 'Vous' : nomComplet(a);
    const masque = c.est_masque ? '<em class="com-meta"> (masqué par le propriétaire, visible par vous seul)</em>' : '';
    return `<div class="commentaire" data-id="${esc(c.id)}">
        <a href="auteur.html?id=${esc(c.etudiant_id)}">${avatarHtml(a)}</a>
        <div class="com-bulle">
            <a class="com-nom" href="auteur.html?id=${esc(c.etudiant_id)}">${esc(nom)}</a>${masque}
            <div class="com-texte">${esc(c.contenu)}</div>
            <div class="com-meta">${esc(dateRelative(c.date_creation))}
                ${proprio ? `<button type="button" data-act="edit">Modifier</button><button type="button" data-act="del">Supprimer</button>` : ''}
            </div>
        </div></div>`;
}

async function chargerCommentaires() {
    const { data, error } = await supabase.from('commentaires').select('*')
        .eq('tfc_id', id).order('date_creation', { ascending: true });
    if (error) { liste.textContent = 'Impossible de charger les commentaires.'; return; }

    const auteurs = await chargerAuteurs(data.map((c) => c.etudiant_id));
    liste.innerHTML = data.length
        ? data.map((c) => htmlCommentaire(c, auteurs.get(c.etudiant_id))).join('')
        : '<p class="aide">Aucun commentaire pour le moment. Soyez le premier !</p>';

    const visibles = data.filter((c) => !c.est_masque).length;
    document.querySelectorAll('.n-com').forEach((el) => { el.textContent = visibles; });
}

// Zone de saisie : seulement pour les étudiants connectés
if (moi) {
    saisie.innerHTML = `<form id="formCommentaire">
        <textarea id="texteCommentaire" rows="3" maxlength="1000" placeholder="Écrivez un commentaire..." required></textarea>
        <button class="btn btn-inline" type="submit" style="margin-top:.6rem">Publier</button></form>`;
    document.getElementById('formCommentaire').addEventListener('submit', async (e) => {
        e.preventDefault();
        const zone = document.getElementById('texteCommentaire');
        const contenu = zone.value.trim();
        if (!contenu) return;
        const bouton = e.target.querySelector('button');
        bouton.disabled = true;
        const { error } = await supabase.from('commentaires').insert([{ tfc_id: id, etudiant_id: moi, contenu }]);
        bouton.disabled = false;
        if (error) return toast("Publication impossible : " + error.message);
        zone.value = '';
        chargerCommentaires();
    });
} else {
    saisie.innerHTML = `<p class="message info">Connectez-vous pour commenter ou aimer ce TFC. <a href="connexion.html">Se connecter</a> · <a href="inscription.html">Créer un compte</a></p>`;
}

// Modifier / supprimer ses propres commentaires
liste.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const bloc = b.closest('.commentaire');
    const idCom = bloc.dataset.id;

    if (b.dataset.act === 'del') {
        if (!confirm('Supprimer ce commentaire ?')) return;
        const { error } = await supabase.from('commentaires').delete().eq('id', idCom);
        if (error) return toast('Suppression impossible : ' + error.message);
        chargerCommentaires();
    } else if (b.dataset.act === 'edit') {
        const zoneTexte = bloc.querySelector('.com-texte');
        const ancien = zoneTexte.textContent;
        zoneTexte.innerHTML = `<textarea rows="3" maxlength="1000"></textarea>
            <div class="com-meta"><button type="button" data-act="save">Enregistrer</button><button type="button" data-act="cancel">Annuler</button></div>`;
        zoneTexte.querySelector('textarea').value = ancien;
    } else if (b.dataset.act === 'save') {
        const contenu = bloc.querySelector('textarea').value.trim();
        if (!contenu) return;
        const { error } = await supabase.from('commentaires').update({ contenu }).eq('id', idCom);
        if (error) return toast('Modification impossible : ' + error.message);
        chargerCommentaires();
    } else if (b.dataset.act === 'cancel') {
        chargerCommentaires();
    }
});
