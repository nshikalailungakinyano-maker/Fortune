// js/admin-ui.js — garde d'accès et menu de l'espace propriétaire
// NB : la vraie protection est dans PostgreSQL (RLS + fonctions). Ici on ne fait que guider l'affichage.
import { supabase } from './supabaseClient.js';
import { exigerConnexion } from './auth.js';
import { monterEntete } from './layout.js';

const ONGLETS = [
    ['proprietaire.html', "Vue d'ensemble", 'accueil'],
    ['admin-etudiants.html', 'Étudiants', 'etudiants'],
    ['admin-tfc.html', 'TFC', 'tfc'],
    ['admin-commentaires.html', 'Commentaires', 'commentaires'],
    ['admin-signalements.html', 'Signalements', 'signalements'],
    ['admin-journal.html', 'Journal privé', 'journal'],
    ['dashboard.html', 'Mon espace étudiant', '']
];

export async function demarrerAdmin(actif) {
    const ctx = await exigerConnexion();
    if (!ctx) return null;
    if (ctx.profil.role !== 'proprietaire') {
        location.replace('dashboard.html');
        return null;
    }
    monterEntete('espace');

    const { count } = await supabase.from('signalements_ouverts').select('tfc_id', { count: 'exact', head: true });
    document.getElementById('menuAdmin').innerHTML = ONGLETS.map(([href, texte, id]) =>
        `<a href="${href}"${id === actif ? ' class="actif"' : ''}>${texte}${id === 'signalements' && count ? ` <span class="pastille">${count}</span>` : ''}</a>`
    ).join('');
    return ctx;
}

// Le propriétaire peut lire tous les profils (policy RLS) : on récupère les étudiants par identifiant
export async function chargerEtudiants(ids) {
    const uniques = [...new Set(ids.filter(Boolean))];
    if (uniques.length === 0) return new Map();
    const { data } = await supabase.from('etudiants').select('*').in('id', uniques);
    return new Map((data || []).map((e) => [e.id, e]));
}
