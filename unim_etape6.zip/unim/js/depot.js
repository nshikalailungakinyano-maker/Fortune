import { supabase } from './supabaseClient.js';
import { exigerEtudiant } from './auth.js';
import { monterEntete, monterMenuEtudiant } from './layout.js';
import { afficherMessage, compterMots } from './utils.js';
import { anneesAcademiques } from './listes.js';
import { BUCKET } from './tfc-ui.js';

const TAILLE_MAX = 20 * 1024 * 1024;   // 20 Mo (identique à la limite du bucket)

const ctx = await exigerEtudiant();
if (ctx) {
    const moi = ctx.session.user.id;
    const msg = document.getElementById('message');
    const form = document.getElementById('formDepot');
    const btn = document.getElementById('btnDepot');
    const val = (id) => document.getElementById(id).value.trim();

    monterEntete('espace');
    monterMenuEtudiant('depot', moi);
    document.getElementById('annee').insertAdjacentHTML('beforeend',
        anneesAcademiques().map((a) => `<option value="${a}">${a}</option>`).join(''));

    const compteur = document.getElementById('compteMots');
    document.getElementById('resume').addEventListener('input', (e) => {
        const n = compterMots(e.target.value);
        compteur.textContent = `${n} mot${n > 1 ? 's' : ''}`;
    });

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        // 1. Informations obligatoires
        const titre = val('titre'), resume = val('resume'), directeur = val('directeur'), annee = val('annee');
        const motsCles = val('motsCles').split(',').map((m) => m.trim()).filter(Boolean).join(', ');
        const fichier = document.getElementById('fichierPdf').files[0];

        if (!titre || !resume || !motsCles || !directeur || !annee || !fichier) {
            return afficherMessage(msg, 'Veuillez renseigner tous les champs et choisir le fichier PDF.', 'erreur');
        }

        // 2. Validité du fichier : extension, taille, et signature « %PDF- » réelle
        if (!fichier.name.toLowerCase().endsWith('.pdf')) {
            return afficherMessage(msg, 'Le fichier doit être au format PDF.', 'erreur');
        }
        if (fichier.size > TAILLE_MAX) {
            return afficherMessage(msg, 'Le fichier dépasse la taille maximale de 20 Mo.', 'erreur');
        }
        const signature = new TextDecoder().decode(await fichier.slice(0, 5).arrayBuffer());
        if (signature !== '%PDF-') {
            return afficherMessage(msg, "Ce fichier n'est pas un PDF valide.", 'erreur');
        }

        btn.disabled = true;
        afficherMessage(msg, 'Envoi du document en cours, ne fermez pas la page...', 'info');

        // 3. Envoi du PDF (dossier = identifiant de l'étudiant) puis enregistrement des informations
        const chemin = `${moi}/${Date.now()}.pdf`;
        let envoye = false;
        try {
            const { error: errFichier } = await supabase.storage.from(BUCKET)
                .upload(chemin, fichier, { contentType: 'application/pdf', upsert: false });
            if (errFichier) throw errFichier;
            envoye = true;

            const { data, error: errBase } = await supabase.from('tfc').insert([{
                etudiant_id: moi, titre, resume, mots_cles: motsCles,
                directeur_recherche: directeur, annee_academique: annee,
                fichier_pdf_url: chemin,          // on garde le CHEMIN ; la lecture se fait par lien signé
                statut: 'publie'
            }]).select('id').single();
            if (errBase) throw errBase;

            afficherMessage(msg, 'Votre TFC a été publié avec succès. Redirection...', 'ok');
            setTimeout(() => { location.href = 'tfc.html?id=' + data.id; }, 1500);
        } catch (err) {
            console.error('Dépôt :', err);
            if (envoye) await supabase.storage.from(BUCKET).remove([chemin]);   // pas de PDF orphelin
            afficherMessage(msg, 'Le dépôt a échoué : ' + err.message, 'erreur');
            btn.disabled = false;
        }
    });
}
