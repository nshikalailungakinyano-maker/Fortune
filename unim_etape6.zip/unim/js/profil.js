import { supabase } from './supabaseClient.js';
import { exigerEtudiant } from './auth.js';
import { monterEntete, monterMenuEtudiant } from './layout.js';
import { afficherMessage, remplirDatalist } from './utils.js';
import { FACULTES, DEPARTEMENTS, PROMOTIONS } from './listes.js';
import { avatarHtml } from './tfc-ui.js';

const ctx = await exigerEtudiant();
if (ctx) {
    const moi = ctx.session.user.id;
    let profil = ctx.profil;
    const msg = document.getElementById('message');
    const msgPhoto = document.getElementById('messagePhoto');
    const val = (id) => document.getElementById(id).value.trim();
    const AVATARS = 'avatars';

    monterEntete('espace');
    monterMenuEtudiant('profil', moi);
    remplirDatalist('listeFacultes', FACULTES);
    remplirDatalist('listeDepartements', DEPARTEMENTS);
    remplirDatalist('listePromotions', PROMOTIONS);

    const remplir = () => {
        for (const c of ['nom', 'postnom', 'prenom', 'sexe', 'matricule', 'faculte', 'departement', 'promotion']) {
            document.getElementById(c).value = profil[c] || '';
        }
        document.getElementById('emailActuel').textContent = profil.email;
        document.getElementById('apercu').innerHTML = avatarHtml(profil, 'grand');
        document.getElementById('btnRetirer').hidden = !profil.photo_url;
    };
    remplir();

    // ----- Informations personnelles
    document.getElementById('formProfil').addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = document.getElementById('btnProfil');
        btn.disabled = true;
        const champs = {
            nom: val('nom'), postnom: val('postnom') || null, prenom: val('prenom'), sexe: val('sexe'),
            matricule: val('matricule'), faculte: val('faculte'), departement: val('departement'), promotion: val('promotion')
        };
        const { error } = await supabase.from('etudiants').update(champs).eq('id', moi);
        btn.disabled = false;
        if (error) {
            return afficherMessage(msg, error.code === '23505' ? 'Ce matricule est déjà utilisé.' : 'Erreur : ' + error.message, 'erreur');
        }
        profil = { ...profil, ...champs };
        remplir();
        afficherMessage(msg, 'Profil mis à jour.', 'ok');
    });

    // ----- Photo : recadrée en carré et réduite (≤ 480 px) avant l'envoi
    async function preparerImage(fichier) {
        const bitmap = await createImageBitmap(fichier);
        const cote = Math.min(bitmap.width, bitmap.height);
        const taille = Math.min(cote, 480);
        const canvas = document.createElement('canvas');
        canvas.width = canvas.height = taille;
        canvas.getContext('2d').drawImage(bitmap, (bitmap.width - cote) / 2, (bitmap.height - cote) / 2, cote, cote, 0, 0, taille, taille);
        return new Promise((ok, ko) => canvas.toBlob((b) => (b ? ok(b) : ko(new Error('Image illisible'))), 'image/jpeg', 0.85));
    }
    const cheminDepuisUrl = (url) => (url && url.includes(`/${AVATARS}/`) ? decodeURIComponent(url.split(`/${AVATARS}/`)[1].split('?')[0]) : null);

    document.getElementById('fichierPhoto').addEventListener('change', async (e) => {
        const fichier = e.target.files[0];
        if (!fichier) return;
        afficherMessage(msgPhoto, 'Envoi de la photo...', 'info');
        try {
            const blob = await preparerImage(fichier);
            const chemin = `${moi}/${Date.now()}.jpg`;
            const { error: errUp } = await supabase.storage.from(AVATARS).upload(chemin, blob, { contentType: 'image/jpeg' });
            if (errUp) throw errUp;
            const { data } = supabase.storage.from(AVATARS).getPublicUrl(chemin);

            const { error } = await supabase.from('etudiants').update({ photo_url: data.publicUrl }).eq('id', moi);
            if (error) throw error;

            const ancien = cheminDepuisUrl(profil.photo_url);
            if (ancien) await supabase.storage.from(AVATARS).remove([ancien]);   // supprime l'ancienne photo
            profil.photo_url = data.publicUrl;
            remplir();
            afficherMessage(msgPhoto, 'Photo mise à jour.', 'ok');
        } catch (err) {
            afficherMessage(msgPhoto, 'Impossible de changer la photo : ' + err.message, 'erreur');
        }
        e.target.value = '';
    });

    document.getElementById('btnRetirer').addEventListener('click', async () => {
        const ancien = cheminDepuisUrl(profil.photo_url);
        const { error } = await supabase.from('etudiants').update({ photo_url: null }).eq('id', moi);
        if (error) return afficherMessage(msgPhoto, 'Erreur : ' + error.message, 'erreur');
        if (ancien) await supabase.storage.from(AVATARS).remove([ancien]);
        profil.photo_url = null;
        remplir();
        afficherMessage(msgPhoto, 'Photo retirée.', 'ok');
    });
}
