// js/listes.js — listes gérées dans l'interface (cahier des charges, section 12)
// Ce sont des SUGGESTIONS : l'étudiant peut aussi saisir librement. À ADAPTER à l'UNIM.
export const FACULTES = [
    'Droit',
    'Sciences économiques et de gestion',
    'Sciences',
    'Lettres et sciences humaines',
    'Médecine',
    'Polytechnique'
];

export const DEPARTEMENTS = [
    // exemple : 'Informatique de gestion', 'Comptabilité', 'Droit privé et judiciaire'
];

export const PROMOTIONS = ['G1', 'G2', 'G3', 'L1', 'L2'];

// Années académiques : de 2020-2021 jusqu'à l'année prochaine (se met à jour toute seule)
export function anneesAcademiques(debut = 2020) {
    const fin = new Date().getFullYear() + 1;
    const liste = [];
    for (let a = fin; a >= debut; a--) liste.push(`${a - 1}-${a}`);
    return liste;
}
