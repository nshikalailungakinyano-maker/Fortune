import { supabase } from './supabaseClient.js';
import { demarrerAdmin, chargerEtudiants } from './admin-ui.js';
import { esc, afficherMessage } from './utils.js';
import { nomComplet } from './tfc-ui.js';

const LIBELLES = {
    creation_compte: 'Création de compte', connexion: 'Connexion', deconnexion: 'Déconnexion',
    depot_tfc: "Dépôt d'un TFC", publication_automatique: 'Publication automatique',
    modification_tfc: "Modification d'un TFC", masquage_tfc: "Masquage d'un TFC",
    republication_tfc: "Republication d'un TFC", signalement_tfc: 'TFC marqué comme signalé',
    suppression_tfc: "Suppression d'un TFC", masquage_commentaire: "Masquage d'un commentaire",
    demasquage_commentaire: "Démasquage d'un commentaire", suppression_commentaire: "Suppression d'un commentaire",
    suspension_compte: "Suspension d'un compte", reactivation_compte: "Réactivation d'un compte",
    signalement_recu: 'Signalement reçu', signalements_traites: 'Signalements traités'
};
const TAILLE = 50;

const ctx = await demarrerAdmin('journal');
if (ctx) {
    const etat = document.getElementById('etat');
    const liste = document.getElementById('liste');
    const filtre = document.getElementById('filtre');
    const btnPlus = document.getElementById('btnPlus');
    let page = 0;

    filtre.insertAdjacentHTML('beforeend', Object.entries(LIBELLES).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join(''));

    async function charger(recommencer) {
        if (recommencer) { page = 0; liste.innerHTML = ''; }
        let req = supabase.from('journal_activites').select('*').order('date_creation', { ascending: false })
            .range(page * TAILLE, page * TAILLE + TAILLE - 1);
        if (filtre.value) req = req.eq('action', filtre.value);
        const { data, error } = await req;
        if (error) return afficherMessage(etat, 'Erreur : ' + error.message, 'erreur');

        const acteurs = await chargerEtudiants(data.map((j) => j.acteur_id));
        afficherMessage(etat, page === 0 && !data.length ? 'Journal vide.' : '', 'info');
        liste.insertAdjacentHTML('beforeend', data.map((j) => `<li class="notif">
            <div><b>${esc(LIBELLES[j.action] || j.action)}</b> — ${esc(j.acteur_id ? nomComplet(acteurs.get(j.acteur_id)) : 'Système')}
                <small>${esc(new Date(j.date_creation).toLocaleString('fr-FR'))} · ${esc(j.cible_type)}${j.details ? ' · ' + esc(j.details) : ''}</small></div></li>`).join(''));
        btnPlus.hidden = data.length < TAILLE;
        page++;
    }

    filtre.addEventListener('change', () => charger(true));
    btnPlus.addEventListener('click', () => charger(false));
    charger(true);
}
