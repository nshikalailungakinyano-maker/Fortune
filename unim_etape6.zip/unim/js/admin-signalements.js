import { supabase } from './supabaseClient.js';
import { demarrerAdmin, chargerEtudiants } from './admin-ui.js';
import { esc, afficherMessage } from './utils.js';
import { dateRelative, nomComplet, toast } from './tfc-ui.js';

const ctx = await demarrerAdmin('signalements');
if (ctx) {
    const etat = document.getElementById('etat');
    const liste = document.getElementById('liste');

    async function charger() {
        const [sigR, marquesR] = await Promise.all([
            supabase.from('signalements_ouverts').select('*'),
            supabase.from('tfc').select('id').eq('statut', 'signale')
        ]);
        if (sigR.error) return afficherMessage(etat, 'Erreur : ' + sigR.error.message, 'erreur');

        const sig = new Map((sigR.data || []).map((s) => [s.tfc_id, s]));
        const ids = [...new Set([...sig.keys(), ...(marquesR.data || []).map((t) => t.id)])];
        if (ids.length === 0) {
            liste.innerHTML = '';
            return afficherMessage(etat, 'Aucun signalement en attente.', 'ok');
        }
        afficherMessage(etat, '', 'info');

        const { data: tfcs } = await supabase.from('tfc').select('*').in('id', ids);
        const auteurs = await chargerEtudiants((tfcs || []).map((t) => t.etudiant_id));

        liste.innerHTML = (tfcs || []).map((t) => {
            const s = sig.get(t.id);
            const motifs = (s?.motifs || []).filter(Boolean);
            return `<article class="carte ligne-tfc" data-id="${esc(t.id)}" data-statut="${esc(t.statut)}">
                <div class="ligne-haut"><h2><a href="tfc.html?id=${esc(t.id)}">${esc(t.titre)}</a></h2>
                    <span class="badge ${esc(t.statut)}">${t.statut === 'publie' ? 'Publié' : t.statut === 'masque' ? 'Masqué' : 'Signalé'}</span></div>
                <p class="meta-ligne">Auteur : ${esc(nomComplet(auteurs.get(t.etudiant_id)))}${s ? ` · ${s.nb} signalement${s.nb > 1 ? 's' : ''}, le dernier ${esc(dateRelative(s.dernier))}` : ''}</p>
                ${motifs.length ? `<ul class="infos">${motifs.map((m) => `<li>« ${esc(m)} »</li>`).join('')}</ul>` : ''}
                <button type="button" class="btn btn-petit btn-danger" data-act="masquer">Masquer le TFC</button>
                <button type="button" class="btn btn-petit btn-contour" data-act="conserver">Conserver (ignorer les signalements)</button>
            </article>`;
        }).join('');
    }

    liste.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-act]');
        if (!b) return;
        const bloc = b.closest('article');
        const id = bloc.dataset.id;

        if (b.dataset.act === 'masquer') {
            const { error } = await supabase.from('tfc').update({ statut: 'masque' }).eq('id', id);
            if (error) return toast('Action impossible : ' + error.message);
        } else if (bloc.dataset.statut === 'signale') {
            const { error } = await supabase.from('tfc').update({ statut: 'publie' }).eq('id', id);
            if (error) return toast('Action impossible : ' + error.message);
        }
        const { error } = await supabase.rpc('proprietaire_traiter_signalements', { p_tfc: id });
        if (error) return toast('Action impossible : ' + error.message);
        charger();
    });

    charger();
}
