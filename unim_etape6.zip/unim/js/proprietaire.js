import { supabase } from './supabaseClient.js';
import { demarrerAdmin } from './admin-ui.js';
import { esc } from './utils.js';

const ctx = await demarrerAdmin('accueil');
if (ctx) {
    document.getElementById('bonjour').textContent = `Bonjour, ${ctx.profil.prenom}`;

    const [tfcsR, etuR, comR, likR, sigR] = await Promise.all([
        supabase.from('tfc').select('id, titre, statut, nombre_vues, annee_academique, etudiant_id').limit(5000),
        supabase.from('etudiants').select('id, faculte, est_actif').limit(5000),
        supabase.from('commentaires').select('id', { count: 'exact', head: true }),
        supabase.from('likes_tfc').select('id', { count: 'exact', head: true }),
        supabase.from('signalements_ouverts').select('tfc_id', { count: 'exact', head: true })
    ]);

    const tfcs = tfcsR.data || [];
    const etus = etuR.data || [];
    const nb = (statut) => tfcs.filter((t) => t.statut === statut).length;
    const vues = tfcs.reduce((s, t) => s + (t.nombre_vues || 0), 0);
    const actifs = etus.filter((e) => e.est_actif !== false).length;

    const cartes = [
        [etus.length, `Étudiants (${actifs} actifs)`],
        [tfcs.length, `TFC (${nb('publie')} publiés)`],
        [vues, 'Vues au total'],
        [comR.count ?? 0, 'Commentaires'],
        [likR.count ?? 0, "J'aime"],
        [sigR.count ?? 0, 'Signalements à traiter']
    ];
    document.getElementById('stats').innerHTML = cartes
        .map(([n, l]) => `<div class="stat"><strong>${esc(n)}</strong><span>${esc(l)}</span></div>`).join('');

    // Répartitions
    const faculteDe = new Map(etus.map((e) => [e.id, e.faculte || 'Non renseignée']));
    const repartition = (items, cle) => {
        const m = new Map();
        items.forEach((x) => m.set(cle(x), (m.get(cle(x)) || 0) + 1));
        return [...m.entries()].sort((a, b) => b[1] - a[1]);
    };
    const tableau = (id, lignes, entete) => {
        document.getElementById(id).innerHTML = lignes.length
            ? `<table class="tableau"><thead><tr><th>${entete}</th><th>TFC</th></tr></thead><tbody>${lignes.map(([k, n]) => `<tr><td>${esc(k)}</td><td>${n}</td></tr>`).join('')}</tbody></table>`
            : '<p class="aide">Aucune donnée.</p>';
    };
    tableau('parFaculte', repartition(tfcs, (t) => faculteDe.get(t.etudiant_id) || 'Non renseignée'), 'Faculté');
    tableau('parAnnee', repartition(tfcs, (t) => t.annee_academique || '—').sort((a, b) => String(b[0]).localeCompare(String(a[0]))), 'Année académique');

    const top = [...tfcs].filter((t) => t.statut === 'publie').sort((a, b) => (b.nombre_vues || 0) - (a.nombre_vues || 0)).slice(0, 5);
    document.getElementById('top').innerHTML = top.length
        ? `<table class="tableau"><thead><tr><th>TFC les plus consultés</th><th>Vues</th></tr></thead><tbody>${top.map((t) => `<tr><td><a href="tfc.html?id=${esc(t.id)}">${esc(t.titre)}</a></td><td>${esc(t.nombre_vues)}</td></tr>`).join('')}</tbody></table>`
        : '<p class="aide">Aucun TFC publié.</p>';
}
