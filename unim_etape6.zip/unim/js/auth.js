// js/auth.js — session, profil, connexion/déconnexion (partagé par toutes les pages)
import { supabase } from './supabaseClient.js';

// Pages de destination. Les pages étudiant/propriétaire seront créées aux étapes suivantes :
// en attendant, elles renvoient vers l'accueil.
export const PAGES = {
    accueil: 'index.html',
    connexion: 'connexion.html',
    completer: 'completer-profil.html',
    etudiant: 'dashboard.html',
    proprietaire: 'proprietaire.html'
};

export const urlAbsolue = (page) => new URL(page, location.href).href;

export async function getSession() {
    const { data: { session } } = await supabase.auth.getSession();
    return session;
}

export async function getProfil(userId) {
    const { data, error } = await supabase.from('etudiants').select('*').eq('id', userId).maybeSingle();
    if (error) {
        console.error('Profil :', error.message);
        return null;
    }
    return data;
}

export const profilComplet = (p) => !!(p && p.matricule && p.faculte && p.departement && p.promotion);

export function pageApresConnexion(profil) {
    if (!profilComplet(profil)) return PAGES.completer;
    return profil.role === 'proprietaire' ? PAGES.proprietaire : PAGES.etudiant;
}

// Vérifie que le profil existe et que le compte est actif ; sinon déconnecte
export async function preparerSession(userId) {
    const profil = await getProfil(userId);
    if (!profil) {
        await supabase.auth.signOut();
        return { erreur: "Profil étudiant introuvable. Contactez l'équipe UNIM." };
    }
    if (profil.est_actif === false) {
        await supabase.auth.signOut();
        return { erreur: "Votre compte a été suspendu. Contactez l'équipe UNIM." };
    }
    return { profil };
}

// Journal privé (connexion / déconnexion). N'empêche jamais l'utilisateur de continuer.
async function journaliser(action) {
    try { await supabase.rpc('journaliser_evenement', { p_action: action }); } catch (e) { /* ignoré */ }
}

export async function journaliserConnexion() {
    if (sessionStorage.getItem('unim_j')) return;
    sessionStorage.setItem('unim_j', '1');
    await journaliser('connexion');
}

export async function deconnecter() {
    await journaliser('deconnexion');
    sessionStorage.removeItem('unim_j');
    await supabase.auth.signOut();
    location.href = PAGES.accueil;
}

// provider : 'google' | 'azure' (Microsoft)
export async function connexionOAuth(provider) {
    const options = { redirectTo: urlAbsolue(PAGES.completer) };
    if (provider === 'azure') options.scopes = 'email';
    const { error } = await supabase.auth.signInWithOAuth({ provider, options });
    if (error) throw error;
}

// À appeler en haut des pages réservées aux étudiants connectés
export async function exigerConnexion() {
    const session = await getSession();
    if (!session) {
        location.replace(PAGES.connexion);
        return null;
    }
    const r = await preparerSession(session.user.id);
    if (r.erreur) {
        location.replace(PAGES.connexion);
        return null;
    }
    return { session, profil: r.profil };
}

// Pages de l'espace étudiant : connexion obligatoire + profil complété (comptes Google/Microsoft)
export async function exigerEtudiant() {
    const ctx = await exigerConnexion();
    if (!ctx) return null;
    if (!profilComplet(ctx.profil)) {
        location.replace(PAGES.completer);
        return null;
    }
    return ctx;
}

// Mémorise (dans ce navigateur) que la personne possède déjà un compte : on cesse alors de lui
// proposer « Créer un compte » en haut de page.
const CLE_CONNU = 'unim_compte_connu';
export function estCompteConnu() {
    try { return localStorage.getItem(CLE_CONNU) === '1'; } catch { return false; }
}
export function marquerCompteConnu() {
    try { localStorage.setItem(CLE_CONNU, '1'); } catch { /* stockage indisponible */ }
}
