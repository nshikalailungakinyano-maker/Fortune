// Tests de sécurité : chaque test tente une action interdite ; il est RÉUSSI quand la base la refuse.
import { supabase } from './supabaseClient.js';
import { getSession } from './auth.js';
import { monterEntete } from './layout.js';
import { esc, afficherMessage } from './utils.js';

const ZERO = '00000000-0000-0000-0000-000000000000';
// Action bloquée = erreur renvoyée, ou aucune ligne touchée / renvoyée
const bloque = (r) => !!r.error || (Array.isArray(r.data) && r.data.length === 0);

monterEntete('');
const session = await getSession();
const moi = session?.user.id ?? null;
let role = null;
if (moi) {
    const { data } = await supabase.from('etudiants').select('role').eq('id', moi).maybeSingle();
    role = data?.role ?? null;
}
document.getElementById('mode').textContent = !moi ? 'Mode actuel : visiteur (non connecté)'
    : role === 'proprietaire' ? 'Mode actuel : PROPRIÉTAIRE — ces tests ne sont pas adaptés, déconnectez-vous ou utilisez un compte étudiant.'
    : 'Mode actuel : étudiant connecté';

const octetsPdf = () => new Blob(['%PDF-1.4 test'], { type: 'application/pdf' });
const envoyerFichier = (dossier) => supabase.storage.from('tfc-documents')
    .upload(`${dossier}/test-${Date.now()}.pdf`, octetsPdf(), { contentType: 'application/pdf' });

function testsVisiteur() {
    return [
        ['Lire les profils des étudiants', () => supabase.from('etudiants').select('id').limit(5), bloque],
        ['Lire le journal privé', () => supabase.from('journal_activites').select('id').limit(5), bloque],
        ['Lire les signalements', () => supabase.from('signalements_ouverts').select('tfc_id').limit(5), bloque],
        ['Lire les notifications', () => supabase.from('notifications').select('id').limit(5), bloque],
        ['Lire des TFC masqués ou signalés', () => supabase.from('tfc').select('id').neq('statut', 'publie').limit(5), bloque],
        ['Publier un commentaire', () => supabase.from('commentaires').insert([{ tfc_id: ZERO, etudiant_id: ZERO, contenu: 'test' }]).select(), bloque],
        ["Ajouter un J'aime", () => supabase.from('likes_tfc').insert([{ tfc_id: ZERO, etudiant_id: ZERO }]).select(), bloque],
        ['Appeler une fonction du propriétaire', () => supabase.rpc('proprietaire_definir_actif', { p_etudiant: ZERO, p_actif: false }), bloque],
        ['Écrire dans le journal', () => supabase.rpc('journaliser_evenement', { p_action: 'connexion' }), bloque],
        ['Signaler un TFC', () => supabase.rpc('signaler_tfc', { p_tfc: ZERO, p_motif: 'test' }), bloque],
        ['Déposer un fichier dans le stockage', () => envoyerFichier(ZERO), (r) => !!r.error]
    ];
}

async function testsEtudiant() {
    const { data: ech } = await supabase.from('tfc').select('id').limit(1);
    const tfcId = ech?.[0]?.id ?? null;
    const needTfc = (fn) => (tfcId ? fn : null);
    return [
        ['Lire les profils des AUTRES étudiants (seul le sien doit apparaître)', () => supabase.from('etudiants').select('id').limit(50), (r) => !r.error && r.data.length <= 1],
        ['Lire le journal privé', () => supabase.from('journal_activites').select('id').limit(5), bloque],
        ['Lire les signalements', () => supabase.from('signalements_ouverts').select('tfc_id').limit(5), bloque],
        ['Se donner le rôle propriétaire', () => supabase.from('etudiants').update({ role: 'proprietaire' }).eq('id', moi).select(), bloque],
        ['Se réactiver soi-même (est_actif)', () => supabase.from('etudiants').update({ est_actif: true }).eq('id', moi).select(), bloque],
        ['Truquer le nombre de vues d\'un TFC', needTfc(() => supabase.from('tfc').update({ nombre_vues: 99999 }).eq('id', tfcId).select()), bloque],
        ['Masquer un TFC (réservé au propriétaire)', needTfc(() => supabase.from('tfc').update({ statut: 'masque' }).eq('id', tfcId).select()), bloque],
        ['Déposer un TFC avec un faux compteur de vues', () => supabase.from('tfc').insert([{ etudiant_id: moi, titre: 'TEST SÉCURITÉ', resume: 'test', annee_academique: '2000-2001', fichier_pdf_url: 'test/test.pdf', nombre_vues: 500 }]).select(), bloque],
        ['Déposer un TFC au nom d\'un autre', () => supabase.from('tfc').insert([{ etudiant_id: ZERO, titre: 'TEST SÉCURITÉ', resume: 'test', annee_academique: '2000-2001', fichier_pdf_url: 'test/test.pdf' }]).select(), bloque],
        ['Commenter au nom d\'un autre étudiant', needTfc(() => supabase.from('commentaires').insert([{ tfc_id: tfcId, etudiant_id: ZERO, contenu: 'test' }]).select()), bloque],
        ['Créer une notification', () => supabase.from('notifications').insert([{ etudiant_id: moi, type: 'test', message: 'test' }]).select(), bloque],
        ['Suspendre un compte (fonction du propriétaire)', () => supabase.rpc('proprietaire_definir_actif', { p_etudiant: ZERO, p_actif: false }), bloque],
        ['Masquer un commentaire (fonction du propriétaire)', () => supabase.rpc('proprietaire_masquer_commentaire', { p_commentaire: ZERO, p_masque: true }), bloque],
        ['Traiter des signalements (fonction du propriétaire)', () => supabase.rpc('proprietaire_traiter_signalements', { p_tfc: ZERO }), bloque],
        ['Déposer un fichier dans le dossier d\'un autre étudiant', () => envoyerFichier(ZERO), (r) => !!r.error]
    ];
}

document.getElementById('btnLancer').addEventListener('click', async (e) => {
    e.target.disabled = true;
    const liste = document.getElementById('resultats');
    const resume = document.getElementById('resume');
    liste.hidden = false;
    liste.innerHTML = '';
    afficherMessage(resume, 'Tests en cours...', 'info');

    const tests = moi ? await testsEtudiant() : testsVisiteur();
    let reussis = 0, echoues = 0;

    for (const [nom, lancer, verifier] of tests) {
        let etat;
        if (!lancer) etat = ['—', 'ignoré (aucun TFC en base pour ce test)'];
        else {
            try {
                const r = await lancer();
                if (verifier(r)) { reussis++; etat = ['✓', 'refusé comme prévu']; }
                else { echoues++; etat = ['✗', 'ACCEPTÉ : faille à corriger !']; }
            } catch (err) {
                reussis++; etat = ['✓', 'refusé (' + err.message + ')'];
            }
        }
        liste.insertAdjacentHTML('beforeend', `<li class="notif${etat[0] === '✗' ? ' nonlue' : ''}"><div><b>${etat[0]}</b> ${esc(nom)}<small>${esc(etat[1])}</small></div></li>`);
    }

    afficherMessage(resume, echoues
        ? `${echoues} test(s) échoué(s) sur ${reussis + echoues} : ne mettez pas le site en ligne avant correction.`
        : `Tous les tests réussis (${reussis}/${reussis}).`, echoues ? 'erreur' : 'ok');
    e.target.disabled = false;
});
