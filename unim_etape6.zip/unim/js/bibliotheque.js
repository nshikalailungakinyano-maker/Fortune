import { getSession } from './auth.js';
import { monterEntete } from './layout.js';
import { creerFlux } from './tfc-ui.js';
import { remplirDatalist } from './utils.js';
import { FACULTES, DEPARTEMENTS, PROMOTIONS, anneesAcademiques } from './listes.js';

const form = document.getElementById('formRecherche');
const champ = (id) => document.getElementById(id);

monterEntete('bibliotheque');
remplirDatalist('listeFacultes', FACULTES);
remplirDatalist('listeDepartements', DEPARTEMENTS);
remplirDatalist('listePromotions', PROMOTIONS);
champ('fAnnee').insertAdjacentHTML('beforeend',
    anneesAcademiques().map((a) => `<option value="${a}">${a}</option>`).join(''));

const lireFiltres = () => ({
    q: champ('q').value, titre: champ('fTitre').value, auteur: champ('fAuteur').value,
    matricule: champ('fMatricule').value, faculte: champ('fFaculte').value,
    departement: champ('fDepartement').value, promotion: champ('fPromotion').value,
    annee: champ('fAnnee').value, motsCles: champ('fMotsCles').value
});

const session = await getSession();
const fil = creerFlux({
    flux: champ('flux'), etat: champ('etat'), btnPlus: champ('btnPlus'),
    moi: session?.user.id ?? null, obtenirFiltres: lireFiltres
});

// Recherche venant de l'accueil ou d'un mot-clé cliqué : bibliotheque.html?q=...
const qUrl = new URLSearchParams(location.search).get('q');
if (qUrl) champ('q').value = qUrl;

form.addEventListener('submit', (e) => { e.preventDefault(); fil.recharger(); });
champ('btnReset').addEventListener('click', () => { form.reset(); fil.recharger(); });

fil.recharger();
