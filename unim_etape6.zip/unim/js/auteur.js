import { supabase } from './supabaseClient.js';
import { getSession } from './auth.js';
import { monterEntete } from './layout.js';
import { creerFlux, estUuid, avatarHtml, nomComplet } from './tfc-ui.js';
import { afficherMessage, esc } from './utils.js';

monterEntete('bibliotheque');
const etat = document.getElementById('etat');
const id = new URLSearchParams(location.search).get('id');

const { data: auteur } = estUuid(id)
    ? await supabase.from('auteurs').select('*').eq('id', id).maybeSingle()
    : { data: null };

if (!auteur) {
    afficherMessage(etat, "Profil introuvable (ou aucun TFC publié par cet étudiant).", 'erreur');
} else {
    document.title = nomComplet(auteur) + ' — UNIM';
    const lignes = [['Faculté', auteur.faculte], ['Département', auteur.departement], ['Promotion', auteur.promotion], ['Matricule', auteur.matricule]]
        .filter(([, v]) => v).map(([l, v]) => `<li><b>${l} :</b> ${esc(v)}</li>`).join('');

    const entete = document.getElementById('profil');
    entete.innerHTML = `${avatarHtml(auteur, 'grand')}<div><h1>${esc(nomComplet(auteur))}</h1><ul class="infos">${lignes}</ul></div>`;
    entete.hidden = false;
    document.getElementById('titreFlux').hidden = false;

    const session = await getSession();
    creerFlux({
        flux: document.getElementById('flux'), etat, btnPlus: document.getElementById('btnPlus'),
        moi: session?.user.id ?? null, obtenirFiltres: () => ({ etudiantId: id })
    }).recharger();
}
