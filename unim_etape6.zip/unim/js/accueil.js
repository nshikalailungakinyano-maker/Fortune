import { monterEntete } from './layout.js';
import { getSession, getProfil, estCompteConnu, PAGES } from './auth.js';

monterEntete('accueil');

const bouton = document.getElementById('btnCreerCompte');
const session = await getSession();
if (session) {
    // Connecté : le bouton mène directement à son espace
    const profil = await getProfil(session.user.id);
    bouton.textContent = 'Mon espace';
    bouton.href = profil?.role === 'proprietaire' ? PAGES.proprietaire : PAGES.etudiant;
} else if (estCompteConnu()) {
    bouton.hidden = true;   // déjà inscrit : inutile de proposer la création de compte
}
