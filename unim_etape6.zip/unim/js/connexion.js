import { supabase } from './supabaseClient.js';
import { getSession, preparerSession, pageApresConnexion, journaliserConnexion, connexionOAuth } from './auth.js';
import { monterEntete } from './layout.js';
import { afficherMessage, traduireErreur } from './utils.js';

const msg = document.getElementById('message');
const form = document.getElementById('formConnexion');
const btn = document.getElementById('btnConnexion');
let echecs = 0;
let bloqueJusqua = 0;

monterEntete('connexion');

// Déjà connecté ? on l'envoie directement à son espace
(async () => {
    const session = await getSession();
    if (!session) return;
    const r = await preparerSession(session.user.id);
    if (r.profil) location.replace(pageApresConnexion(r.profil));
})();

form.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (Date.now() < bloqueJusqua) {
        afficherMessage(msg, 'Trop de tentatives. Réessayez dans une minute.', 'erreur');
        return;
    }

    btn.disabled = true;
    afficherMessage(msg, 'Connexion en cours...', 'info');

    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('motDePasse').value;

    const { data, error } = await supabase.auth.signInWithPassword({ email, password });

    if (error) {
        echecs++;
        if (echecs >= 5) { bloqueJusqua = Date.now() + 60000; echecs = 0; }
        afficherMessage(msg, traduireErreur(error.message), 'erreur');
        btn.disabled = false;
        return;
    }

    const r = await preparerSession(data.user.id);
    if (r.erreur) {
        afficherMessage(msg, r.erreur, 'erreur');
        btn.disabled = false;
        return;
    }

    await journaliserConnexion();
    location.href = pageApresConnexion(r.profil);
});

async function lancerOAuth(provider) {
    afficherMessage(msg, 'Redirection...', 'info');
    try {
        await connexionOAuth(provider);
    } catch (err) {
        afficherMessage(msg, traduireErreur(err.message), 'erreur');
    }
}
document.getElementById('btnGoogle').addEventListener('click', () => lancerOAuth('google'));
document.getElementById('btnMicrosoft').addEventListener('click', () => lancerOAuth('azure'));
