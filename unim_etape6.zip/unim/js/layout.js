// js/layout.js — en-tête commun + enregistrement de la PWA
import { supabase } from './supabaseClient.js';
import { getSession, getProfil, deconnecter, PAGES, estCompteConnu, marquerCompteConnu } from './auth.js';
import { esc } from './utils.js';

export async function monterEntete(actif = '') {
    const el = document.getElementById('entete');
    if (!el) return;

    const session = await getSession();
    const profil = session ? await getProfil(session.user.id) : null;

    const lien = (href, texte, id) =>
        `<a href="${href}"${actif === id ? ' class="actif"' : ''}>${texte}</a>`;

    let droite;
    if (session) {
        marquerCompteConnu();
        const espace = profil?.role === 'proprietaire' ? PAGES.proprietaire : PAGES.etudiant;
        droite = `${lien(espace, 'Mon espace', 'espace')}
                  <span>${esc(profil?.prenom || 'Connecté')}</span>
                  <button type="button" id="btnDeconnexion">Déconnexion</button>`;
    } else if (estCompteConnu()) {
        // Déjà inscrit : seulement un accès discret à la connexion
        droite = `<a class="bouton" href="connexion.html">Se connecter</a>`;
    } else {
        // Premier passage : on propose de se connecter ou de créer un compte
        droite = `<a class="bouton" href="connexion.html">Connexion</a>
                  <a class="bouton plein" href="inscription.html">Créer un compte</a>`;
    }

    el.className = 'entete';
    el.innerHTML = `<a class="logo" href="index.html">UNIM</a>
        <nav>${lien('index.html', 'Accueil', 'accueil')}${lien('bibliotheque.html', 'Bibliothèque', 'bibliotheque')}${droite}</nav>`;

    document.getElementById('btnDeconnexion')?.addEventListener('click', deconnecter);
}

const ONGLETS = [
    ['dashboard.html', 'Tableau de bord', 'dashboard'],
    ['mes-tfc.html', 'Mes TFC', 'mes-tfc'],
    ['depot.html', 'Déposer un TFC', 'depot'],
    ['mes-commentaires.html', 'Mes commentaires', 'mes-commentaires'],
    ['notifications.html', 'Notifications', 'notifications'],
    ['profil.html', 'Mon profil', 'profil'],
    ['securite.html', 'Sécurité', 'securite']
];

// Barre de navigation de l'espace étudiant
export async function monterMenuEtudiant(actif, userId) {
    const el = document.getElementById('menuEtudiant');
    if (!el) return;
    const { count } = await supabase.from('notifications')
        .select('id', { count: 'exact', head: true })
        .eq('etudiant_id', userId).eq('est_lu', false);
    el.innerHTML = ONGLETS.map(([href, texte, id]) =>
        `<a href="${href}"${id === actif ? ' class="actif"' : ''}>${texte}${id === 'notifications' && count ? ` <span class="pastille">${count}</span>` : ''}</a>`
    ).join('');
}

// PWA : service worker (nécessite https ou localhost)
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch((e) => console.warn('Service worker :', e.message));
}
