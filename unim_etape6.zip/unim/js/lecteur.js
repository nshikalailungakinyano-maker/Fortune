import { supabase } from './supabaseClient.js';
import { monterEntete } from './layout.js';
import { BUCKET, estUuid, telecharger, toast } from './tfc-ui.js';
import { afficherMessage } from './utils.js';

monterEntete('bibliotheque');
const etat = document.getElementById('etat');
const zone = document.getElementById('pages');
const id = new URLSearchParams(location.search).get('id');

const { data: tfc } = estUuid(id)
    ? await supabase.from('tfc').select('id, titre, fichier_pdf_url, statut').eq('id', id).maybeSingle()
    : { data: null };

if (!tfc) {
    afficherMessage(etat, "TFC introuvable ou non publié.", 'erreur');
} else {
    document.title = tfc.titre + ' — UNIM';
    document.getElementById('titre').textContent = tfc.titre;
    document.getElementById('lienFiche').href = 'tfc.html?id=' + tfc.id;
    document.getElementById('barre').hidden = false;
    document.getElementById('btnDl').addEventListener('click', () => telecharger(tfc.fichier_pdf_url, tfc.titre));

    const { data: lien, error } = await supabase.storage.from(BUCKET).createSignedUrl(tfc.fichier_pdf_url, 3600);
    if (error || !lien) {
        afficherMessage(etat, "Le fichier PDF est introuvable.", 'erreur');
    } else {
        const ouvrir = document.getElementById('lienOnglet');
        ouvrir.href = lien.signedUrl;
        compterVue(tfc.id);
        afficherPdf(lien.signedUrl);
    }
}

// Une ouverture = une vue ; un simple rafraîchissement (moins de 30 s) n'est pas recompté
function compterVue(idTfc) {
    const cle = 'unim_vue_' + idTfc;
    const derniere = Number(sessionStorage.getItem(cle) || 0);
    if (Date.now() - derniere < 30000) return;
    sessionStorage.setItem(cle, String(Date.now()));
    supabase.rpc('incrementer_vues', { p_tfc_id: idTfc }).then(({ error }) => {
        if (error) console.warn('Compteur de vues :', error.message);
    });
}

// Lecteur PDF intégré (pdf.js) : fonctionne sur mobile comme sur ordinateur, pages affichées au fil du défilement
async function afficherPdf(url) {
    const pdfjs = window.pdfjsLib;
    if (!pdfjs) {
        afficherMessage(etat, "Lecteur indisponible : utilisez « Ouvrir dans un nouvel onglet ».", 'erreur');
        return;
    }
    pdfjs.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
    afficherMessage(etat, 'Chargement du document...', 'info');

    try {
        const doc = await pdfjs.getDocument({ url, isEvalSupported: false }).promise;
        const premiere = await doc.getPage(1);
        const base = premiere.getViewport({ scale: 1 });
        const ratio = window.devicePixelRatio || 1;

        const observateur = new IntersectionObserver((entrees) => {
            entrees.forEach(async (en) => {
                if (!en.isIntersecting) return;
                const canvas = en.target;
                observateur.unobserve(canvas);
                const page = await doc.getPage(Number(canvas.dataset.page));
                const echelle = (zone.clientWidth / page.getViewport({ scale: 1 }).width) * ratio;
                const vp = page.getViewport({ scale: echelle });
                canvas.width = vp.width;
                canvas.height = vp.height;
                canvas.style.aspectRatio = `${vp.width} / ${vp.height}`;
                await page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise;
            });
        }, { rootMargin: '800px 0px' });

        for (let i = 1; i <= doc.numPages; i++) {
            const c = document.createElement('canvas');
            c.className = 'pdf-page';
            c.dataset.page = i;
            c.style.aspectRatio = `${base.width} / ${base.height}`;
            zone.appendChild(c);
            observateur.observe(c);
        }
        document.getElementById('nbPages').textContent = `${doc.numPages} page${doc.numPages > 1 ? 's' : ''}`;
        afficherMessage(etat, '', 'info');
    } catch (err) {
        console.error('PDF :', err);
        afficherMessage(etat, "Impossible d'afficher le document ici : utilisez « Ouvrir dans un nouvel onglet ».", 'erreur');
        toast('Lecture intégrée impossible.');
    }
}
