import { supabase } from './supabaseClient.js';
import { exigerEtudiant } from './auth.js';
import { monterEntete, monterMenuEtudiant } from './layout.js';
import { esc, afficherMessage } from './utils.js';
import { compte, dateRelative, brancherActions, icone } from './tfc-ui.js';

const STATUTS = {
    publie: ['Publié', 'Visible par tous dans la bibliothèque.'],
    masque: ['Masqué', "Retiré temporairement de la bibliothèque par le propriétaire."],
    signale: ['Signalé', "Un signalement est en cours d'examen ; le TFC n'est plus visible."]
};

const ctx = await exigerEtudiant();
if (ctx) {
    const moi = ctx.session.user.id;
    monterEntete('espace');
    monterMenuEtudiant('mes-tfc', moi);
    const etat = document.getElementById('etat');
    const liste = document.getElementById('liste');

    const { data, error } = await supabase.from('tfc')
        .select('*, likes_tfc(count), commentaires(count)')
        .eq('etudiant_id', moi).order('date_depot', { ascending: false });

    if (error) {
        afficherMessage(etat, 'Erreur : ' + error.message, 'erreur');
    } else if (data.length === 0) {
        afficherMessage(etat, "Vous n'avez pas encore déposé de TFC.", 'info');
    } else {
        liste.innerHTML = data.map((t) => {
            const [libelle, aide] = STATUTS[t.statut] || [t.statut, ''];
            return `<article class="carte ligne-tfc">
                <div class="ligne-haut"><h2><a href="tfc.html?id=${esc(t.id)}">${esc(t.titre)}</a></h2>
                    <span class="badge ${esc(t.statut)}">${esc(libelle)}</span></div>
                <p class="aide" style="text-align:left;margin:.2rem 0">${esc(aide)}</p>
                <p class="meta-ligne">Déposé ${esc(dateRelative(t.date_depot))} · ${esc(t.annee_academique)} ·
                    ${icone('oeil', false, 14)} ${esc(t.nombre_vues)} vues · ${compte(t.likes_tfc)} J'aime · ${compte(t.commentaires)} commentaires</p>
                <div class="media-btns" style="margin-top:.6rem">
                    <a class="btn" href="lecteur.html?id=${esc(t.id)}">${icone('lire')} Lire</a>
                    <button type="button" class="btn btn-contour" data-act="dl" data-chemin="${esc(t.fichier_pdf_url)}" data-titre="${esc(t.titre)}">${icone('telecharger')} Télécharger</button>
                </div></article>`;
        }).join('');
        brancherActions(liste, moi);
    }
}
