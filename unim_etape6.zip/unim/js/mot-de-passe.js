// Mot de passe oublié (demande du lien) + définition du nouveau mot de passe
import { supabase } from './supabaseClient.js';
import { urlAbsolue, PAGES } from './auth.js';
import { monterEntete } from './layout.js';
import { afficherMessage, traduireErreur, MOT_DE_PASSE_MIN } from './utils.js';

const msg = document.getElementById('message');
const blocDemande = document.getElementById('blocDemande');
const blocNouveau = document.getElementById('blocNouveau');

monterEntete('');

// Quand l'étudiant clique sur le lien reçu par e-mail, Supabase déclenche cet événement
supabase.auth.onAuthStateChange((evenement) => {
    if (evenement === 'PASSWORD_RECOVERY') {
        blocDemande.hidden = true;
        blocNouveau.hidden = false;
        afficherMessage(msg, '', 'info');
    }
});

document.getElementById('formDemande').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('btnDemande');
    btn.disabled = true;

    const email = document.getElementById('email').value.trim();
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: urlAbsolue('mot-de-passe.html')
    });

    if (error && /rate|security|too many/i.test(error.message)) {
        afficherMessage(msg, traduireErreur(error.message), 'erreur');
    } else {
        // Message identique que l'adresse existe ou non (évite de révéler qui a un compte)
        afficherMessage(msg, 'Si cette adresse est enregistrée, un lien de réinitialisation vient de vous être envoyé.', 'ok');
    }
    setTimeout(() => { btn.disabled = false; }, 30000);
});

document.getElementById('formNouveau').addEventListener('submit', async (e) => {
    e.preventDefault();
    const mdp = document.getElementById('nouveauMdp').value;

    if (mdp.length < MOT_DE_PASSE_MIN) {
        return afficherMessage(msg, `Le mot de passe doit contenir au moins ${MOT_DE_PASSE_MIN} caractères.`, 'erreur');
    }
    if (mdp !== document.getElementById('confirmationMdp').value) {
        return afficherMessage(msg, 'Les deux mots de passe ne correspondent pas.', 'erreur');
    }

    const { error } = await supabase.auth.updateUser({ password: mdp });
    if (error) return afficherMessage(msg, traduireErreur(error.message), 'erreur');

    afficherMessage(msg, 'Mot de passe modifié. Vous pouvez vous connecter.', 'ok');
    await supabase.auth.signOut();
    setTimeout(() => { location.href = PAGES.connexion; }, 2000);
});
