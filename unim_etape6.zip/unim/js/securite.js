import { supabase } from './supabaseClient.js';
import { exigerEtudiant, deconnecter, urlAbsolue, PAGES } from './auth.js';
import { monterEntete, monterMenuEtudiant } from './layout.js';
import { afficherMessage, traduireErreur, MOT_DE_PASSE_MIN } from './utils.js';

const ctx = await exigerEtudiant();
if (ctx) {
    const moi = ctx.session.user.id;
    const msg = document.getElementById('message');
    const email = ctx.session.user.email;
    monterEntete('espace');
    monterMenuEtudiant('securite', moi);
    document.getElementById('emailActuel').textContent = email;

    // Compte Google / Microsoft : mot de passe et e-mail sont gérés chez le fournisseur
    const fournisseur = ctx.session.user.app_metadata?.provider || 'email';
    if (fournisseur !== 'email') {
        document.getElementById('blocMdp').hidden = true;
        document.getElementById('blocEmail').hidden = true;
        document.getElementById('blocFournisseur').hidden = false;
    }

    document.getElementById('formMdp').addEventListener('submit', async (e) => {
        e.preventDefault();
        const actuel = document.getElementById('mdpActuel').value;
        const nouveau = document.getElementById('mdpNouveau').value;
        if (nouveau.length < MOT_DE_PASSE_MIN) return afficherMessage(msg, `Le nouveau mot de passe doit contenir au moins ${MOT_DE_PASSE_MIN} caractères.`, 'erreur');
        if (nouveau !== document.getElementById('mdpConfirmation').value) return afficherMessage(msg, 'Les deux mots de passe ne correspondent pas.', 'erreur');
        if (nouveau === actuel) return afficherMessage(msg, "Le nouveau mot de passe doit être différent de l'ancien.", 'erreur');

        // Vérification d'identité : on redemande le mot de passe actuel
        const { error: errId } = await supabase.auth.signInWithPassword({ email, password: actuel });
        if (errId) return afficherMessage(msg, 'Mot de passe actuel incorrect.', 'erreur');

        const { error } = await supabase.auth.updateUser({ password: nouveau });
        if (error) return afficherMessage(msg, traduireErreur(error.message), 'erreur');
        e.target.reset();
        afficherMessage(msg, 'Mot de passe modifié. Une notification de sécurité a été enregistrée.', 'ok');
    });

    document.getElementById('formEmail').addEventListener('submit', async (e) => {
        e.preventDefault();
        const nouvelle = document.getElementById('nouvelEmail').value.trim();
        if (nouvelle.toLowerCase() === email.toLowerCase()) return afficherMessage(msg, "C'est déjà votre adresse actuelle.", 'erreur');

        const { error } = await supabase.auth.updateUser({ email: nouvelle }, { emailRedirectTo: urlAbsolue(PAGES.connexion) });
        if (error) return afficherMessage(msg, traduireErreur(error.message), 'erreur');
        e.target.reset();
        afficherMessage(msg, "Un e-mail de confirmation a été envoyé. Le changement ne sera effectif qu'après avoir cliqué sur le lien reçu (vérifiez aussi votre ancienne adresse).", 'ok');
    });

    document.getElementById('btnCetAppareil').addEventListener('click', deconnecter);

    document.getElementById('btnTous').addEventListener('click', async () => {
        if (!confirm('Vous déconnecter de tous vos appareils ?')) return;
        sessionStorage.removeItem('unim_j');
        await supabase.auth.signOut({ scope: 'global' });
        location.href = PAGES.connexion;
    });
}
