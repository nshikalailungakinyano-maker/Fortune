import { supabase } from './supabaseClient.js';
import { demarrerAdmin, chargerEtudiants } from './admin-ui.js';
import { esc, afficherMessage } from './utils.js';
import { dateRelative, nomComplet, toast } from './tfc-ui.js';

const ctx = await demarrerAdmin('commentaires');
if (ctx) {
    const etat = document.getElementById('etat');
    const liste = document.getElementById('liste');
    const filtre = document.getElementById('filtre');

    async function charger() {
        let req = supabase.from('commentaires').select('*, tfc(id, titre)').order('date_creation', { ascending: false }).limit(200);
        if (filtre.value === 'masques') req = req.eq('est_masque', true);
        const { data, error } = await req;
        if (error) return afficherMessage(etat, 'Erreur : ' + error.message, 'erreur');

        const auteurs = await chargerEtudiants(data.map((c) => c.etudiant_id));
        afficherMessage(etat, data.length ? '' : 'Aucun commentaire.', 'info');
        liste.innerHTML = data.map((c) => `<article class="carte" data-id="${esc(c.id)}">
            <div class="ligne-haut"><strong>${esc(nomComplet(auteurs.get(c.etudiant_id)))}</strong>
                ${c.est_masque ? '<span class="badge masque">Masqué</span>' : ''}</div>
            <p class="meta-ligne">Sur ${c.tfc ? `<a href="tfc.html?id=${esc(c.tfc.id)}#commentaires">${esc(c.tfc.titre)}</a>` : 'un TFC'} · ${esc(dateRelative(c.date_creation))}</p>
            <div class="com-texte">${esc(c.contenu)}</div>
            <div style="margin-top:.6rem">
                <button type="button" class="btn btn-petit ${c.est_masque ? '' : 'btn-contour'}" data-act="masquer" data-valeur="${c.est_masque ? 'non' : 'oui'}">${c.est_masque ? 'Démasquer' : 'Masquer'}</button>
                <button type="button" class="btn btn-petit btn-danger" data-act="suppr">Supprimer</button></div>
        </article>`).join('');
    }

    filtre.addEventListener('change', charger);

    liste.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-act]');
        if (!b) return;
        const id = b.closest('article').dataset.id;
        if (b.dataset.act === 'masquer') {
            const { error } = await supabase.rpc('proprietaire_masquer_commentaire', { p_commentaire: id, p_masque: b.dataset.valeur === 'oui' });
            if (error) return toast('Action impossible : ' + error.message);
        } else {
            if (!confirm('Supprimer définitivement ce commentaire ?')) return;
            const { error } = await supabase.from('commentaires').delete().eq('id', id);
            if (error) return toast('Suppression impossible : ' + error.message);
        }
        charger();
    });

    charger();
}
