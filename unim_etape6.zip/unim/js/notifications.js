import { supabase } from './supabaseClient.js';
import { exigerEtudiant } from './auth.js';
import { monterEntete, monterMenuEtudiant } from './layout.js';
import { esc, afficherMessage } from './utils.js';
import { dateRelative } from './tfc-ui.js';

const TYPES = {
    statut_tfc: ['Dépôt', 'mes-tfc.html'],
    reponse_commentaire: ['Commentaire', 'mes-commentaires.html'],
    compte: ['Compte', null],
    securite: ['Sécurité', 'securite.html']
};

const ctx = await exigerEtudiant();
if (ctx) {
    const moi = ctx.session.user.id;
    const etat = document.getElementById('etat');
    const liste = document.getElementById('liste');
    monterEntete('espace');

    async function charger() {
        monterMenuEtudiant('notifications', moi);
        const { data, error } = await supabase.from('notifications').select('*')
            .eq('etudiant_id', moi).order('date_creation', { ascending: false }).limit(50);
        if (error) return afficherMessage(etat, 'Erreur : ' + error.message, 'erreur');

        afficherMessage(etat, data.length ? '' : 'Aucune notification pour le moment.', 'info');
        document.getElementById('btnToutLu').hidden = !data.some((n) => !n.est_lu);
        liste.innerHTML = data.map((n) => {
            const [type, page] = TYPES[n.type] || [n.type, null];
            return `<li class="notif${n.est_lu ? '' : ' nonlue'}" data-id="${esc(n.id)}">
                <div><b>${esc(type)}</b> — ${esc(n.message)}
                    <small>${esc(dateRelative(n.date_creation))}${page ? ` · <a href="${page}">Voir</a>` : ''}</small></div>
                <div class="com-meta">${n.est_lu ? '' : '<button type="button" data-act="lu">Marquer comme lu</button>'}
                    <button type="button" data-act="suppr">Supprimer</button></div></li>`;
        }).join('');
    }

    liste.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-act]');
        if (!b) return;
        const id = b.closest('.notif').dataset.id;
        if (b.dataset.act === 'lu') await supabase.from('notifications').update({ est_lu: true }).eq('id', id);
        if (b.dataset.act === 'suppr') await supabase.from('notifications').delete().eq('id', id);
        charger();
    });

    document.getElementById('btnToutLu').addEventListener('click', async () => {
        await supabase.from('notifications').update({ est_lu: true }).eq('etudiant_id', moi).eq('est_lu', false);
        charger();
    });

    charger();
}
