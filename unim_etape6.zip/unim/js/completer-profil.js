// Arrivée après Google / Microsoft : l'étudiant complète les informations académiques.
import { supabase } from './supabaseClient.js';
import { getSession, preparerSession, profilComplet, pageApresConnexion, journaliserConnexion, PAGES } from './auth.js';
import { monterEntete } from './layout.js';
import { afficherMessage, remplirDatalist } from './utils.js';
import { FACULTES, DEPARTEMENTS, PROMOTIONS } from './listes.js';

const msg = document.getElementById('message');
const form = document.getElementById('formProfil');
const btn = document.getElementById('btnProfil');
const val = (id) => document.getElementById(id).value.trim();
const A_COMPLETER = 'À compléter';

monterEntete('');
remplirDatalist('listeFacultes', FACULTES);
remplirDatalist('listeDepartements', DEPARTEMENTS);
remplirDatalist('listePromotions', PROMOTIONS);

const session = await getSession();
if (!session) {
    location.replace(PAGES.connexion);
} else {
    const r = await preparerSession(session.user.id);
    if (r.erreur) {
        afficherMessage(msg, r.erreur, 'erreur');
        setTimeout(() => location.replace(PAGES.connexion), 2500);
    } else {
        await journaliserConnexion();

        if (profilComplet(r.profil)) {
            location.replace(pageApresConnexion(r.profil));
        } else {
            const p = r.profil;
            const champ = (id, v) => { document.getElementById(id).value = (v && v !== A_COMPLETER) ? v : ''; };
            champ('nom', p.nom); champ('postnom', p.postnom); champ('prenom', p.prenom);
            champ('sexe', p.sexe); champ('matricule', p.matricule); champ('faculte', p.faculte);
            champ('departement', p.departement); champ('promotion', p.promotion);
            form.hidden = false;

            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                btn.disabled = true;
                afficherMessage(msg, 'Enregistrement...', 'info');

                const { error } = await supabase.from('etudiants').update({
                    nom: val('nom'), postnom: val('postnom') || null, prenom: val('prenom'),
                    sexe: val('sexe'), matricule: val('matricule'), faculte: val('faculte'),
                    departement: val('departement'), promotion: val('promotion')
                }).eq('id', session.user.id);

                if (error) {
                    const doublon = error.code === '23505';
                    afficherMessage(msg, doublon ? 'Ce matricule est déjà utilisé.' : 'Erreur : ' + error.message, 'erreur');
                    btn.disabled = false;
                    return;
                }
                afficherMessage(msg, 'Profil enregistré ! Redirection...', 'ok');
                setTimeout(() => location.replace(PAGES.etudiant), 900);
            });
        }
    }
}
