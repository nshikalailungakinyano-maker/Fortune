// js/utils.js — fonctions partagées par toutes les pages
export const MOT_DE_PASSE_MIN = 8;

// Échappe le HTML (à utiliser dès qu'un texte venant de la base passe par innerHTML)
export function esc(valeur) {
    return String(valeur ?? '').replace(/[&<>"']/g, (c) => (
        { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));
}

// Accepte uniquement les liens http(s)
export function urlSure(url) {
    try {
        const u = new URL(url);
        return (u.protocol === 'https:' || u.protocol === 'http:') ? u.href : '';
    } catch {
        return '';
    }
}

export function compterMots(texte) {
    return texte.trim().split(/\s+/).filter(Boolean).length;
}

// type : 'info' | 'ok' | 'erreur'
export function afficherMessage(el, texte, type = 'info') {
    if (!el) return;
    el.textContent = texte;
    el.className = 'message ' + type;
    el.hidden = !texte;
}

export function remplirDatalist(id, valeurs) {
    const dl = document.getElementById(id);
    if (!dl) return;
    dl.innerHTML = valeurs.map((v) => `<option value="${esc(v)}"></option>`).join('');
}

export function traduireErreur(message = '') {
    const m = message.toLowerCase();
    if (m.includes('invalid login credentials')) return 'E-mail ou mot de passe incorrect.';
    if (m.includes('email not confirmed')) return "Veuillez d'abord confirmer votre adresse e-mail (lien reçu par mail).";
    if (m.includes('user already registered')) return 'Cet e-mail est déjà utilisé.';
    if (m.includes('password should be at least')) return `Le mot de passe doit contenir au moins ${MOT_DE_PASSE_MIN} caractères.`;
    if (m.includes('same password') || m.includes('different from the old')) return "Le nouveau mot de passe doit être différent de l'ancien.";
    if (m.includes('rate limit') || m.includes('for security purposes') || m.includes('too many')) {
        return 'Trop de tentatives. Patientez un instant avant de réessayer.';
    }
    if (m.includes('database error saving new user')) {
        return 'Inscription impossible : vérifiez vos informations (le matricule est peut-être déjà utilisé).';
    }
    if (m.includes('failed to fetch') || m.includes('network')) return 'Problème de connexion Internet.';
    return message || 'Une erreur est survenue.';
}
