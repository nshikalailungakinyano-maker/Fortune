import { supabase } from './supabaseClient.js';
import { exigerEtudiant } from './auth.js';
import { monterEntete, monterMenuEtudiant } from './layout.js';
import { esc } from './utils.js';
import { compte, dateRelative } from './tfc-ui.js';

const ctx = await exigerEtudiant();
if (ctx) {
    const moi = ctx.session.user.id;
    const fixer = (id, v) => { document.getElementById(id).textContent = v; };
    monterEntete('espace');
    monterMenuEtudiant('dashboard', moi);
    fixer('bonjour', `Bonjour, ${ctx.profil.prenom}`);

    const [{ data: tfcs }, { data: notifs }] = await Promise.all([
        supabase.from('tfc').select('id, statut, nombre_vues, likes_tfc(count), commentaires(count)').eq('etudiant_id', moi),
        supabase.from('notifications').select('*').eq('etudiant_id', moi).order('date_creation', { ascending: false }).limit(5)
    ]);

    const liste = tfcs || [];
    const somme = (f) => liste.reduce((t, x) => t + f(x), 0);
    fixer('sTfc', liste.length);
    fixer('sVues', somme((x) => x.nombre_vues || 0));
    fixer('sLikes', somme((x) => compte(x.likes_tfc)));
    fixer('sComs', somme((x) => compte(x.commentaires)));

    const retires = liste.filter((x) => x.statut !== 'publie').length;
    if (retires) {
        const alerte = document.getElementById('alerte');
        alerte.textContent = `${retires} de vos TFC ${retires > 1 ? 'sont masqués ou signalés' : 'est masqué ou signalé'} : consultez « Mes TFC ».`;
        alerte.hidden = false;
    }

    const zone = document.getElementById('notifs');
    zone.innerHTML = (notifs && notifs.length)
        ? notifs.map((n) => `<li class="notif${n.est_lu ? '' : ' nonlue'}"><span>${esc(n.message)}</span><small>${esc(dateRelative(n.date_creation))}</small></li>`).join('')
        : '<li class="aide">Aucune notification pour le moment.</li>';
}
