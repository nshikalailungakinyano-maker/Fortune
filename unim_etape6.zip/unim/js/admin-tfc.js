import { supabase } from './supabaseClient.js';
import { demarrerAdmin, chargerEtudiants } from './admin-ui.js';
import { esc, afficherMessage } from './utils.js';
import { compte, dateRelative, nomComplet, toast, BUCKET } from './tfc-ui.js';

const LIBELLES = { publie: 'Publié', masque: 'Masqué', signale: 'Signalé' };

const ctx = await demarrerAdmin('tfc');
if (ctx) {
    const etat = document.getElementById('etat');
    const liste = document.getElementById('liste');
    const filtreStatut = document.getElementById('filtreStatut');
    const recherche = document.getElementById('recherche');
    let tfcs = [];
    let auteurs = new Map();

    async function charger() {
        const { data, error } = await supabase.from('tfc').select('*, likes_tfc(count), commentaires(count)')
            .order('date_depot', { ascending: false }).limit(300);
        if (error) return afficherMessage(etat, 'Erreur : ' + error.message, 'erreur');
        tfcs = data;
        auteurs = await chargerEtudiants(data.map((t) => t.etudiant_id));
        rendre();
    }

    function boutonsStatut(t) {
        const b = (statut, texte, classe = '') => `<button type="button" class="btn btn-petit ${classe}" data-act="statut" data-statut="${statut}">${texte}</button>`;
        if (t.statut === 'publie') return b('masque', 'Masquer', 'btn-danger') + b('signale', 'Marquer signalé', 'btn-contour');
        if (t.statut === 'masque') return b('publie', 'Republier');
        return b('publie', 'Republier') + b('masque', 'Masquer', 'btn-danger');
    }

    function rendre() {
        const q = recherche.value.trim().toLowerCase();
        const vus = tfcs.filter((t) => (!filtreStatut.value || t.statut === filtreStatut.value)
            && (!q || (t.titre + ' ' + nomComplet(auteurs.get(t.etudiant_id))).toLowerCase().includes(q)));
        afficherMessage(etat, vus.length ? `${vus.length} TFC` : 'Aucun TFC trouvé.', 'info');

        liste.innerHTML = vus.map((t) => `<article class="carte ligne-tfc" data-id="${esc(t.id)}" data-chemin="${esc(t.fichier_pdf_url)}">
            <div class="ligne-haut"><h2><a href="tfc.html?id=${esc(t.id)}">${esc(t.titre)}</a></h2>
                <span class="badge ${esc(t.statut)}">${esc(LIBELLES[t.statut] || t.statut)}</span></div>
            <p class="meta-ligne">${esc(nomComplet(auteurs.get(t.etudiant_id)))} · déposé ${esc(dateRelative(t.date_depot))} · ${esc(t.annee_academique)} ·
                ${esc(t.nombre_vues)} vues · ${compte(t.likes_tfc)} J'aime · ${compte(t.commentaires)} commentaires</p>
            <div>${boutonsStatut(t)}<button type="button" class="btn btn-petit btn-danger" data-act="suppr">Supprimer</button></div>
            <details class="avance"><summary>Corriger les informations</summary>
                <form class="form-corriger">
                    <label>Titre</label><input name="titre" value="${esc(t.titre)}" maxlength="300" required>
                    <label>Résumé</label><textarea name="resume" rows="5" maxlength="3000" required>${esc(t.resume)}</textarea>
                    <label>Mots-clés</label><input name="mots_cles" value="${esc(t.mots_cles)}">
                    <div class="grille"><div><label>Directeur de recherche</label><input name="directeur_recherche" value="${esc(t.directeur_recherche)}"></div>
                        <div><label>Année académique</label><input name="annee_academique" value="${esc(t.annee_academique)}" required></div></div>
                    <button type="submit" class="btn btn-petit" style="margin-top:.8rem">Enregistrer</button>
                </form></details>
        </article>`).join('');
    }

    filtreStatut.addEventListener('change', rendre);
    recherche.addEventListener('input', rendre);

    liste.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-act]');
        if (!b) return;
        const bloc = b.closest('article');
        const id = bloc.dataset.id;

        if (b.dataset.act === 'statut') {
            const { error } = await supabase.from('tfc').update({ statut: b.dataset.statut }).eq('id', id);
            if (error) return toast('Action impossible : ' + error.message);
            charger();
        } else if (b.dataset.act === 'suppr') {
            if (!confirm('Supprimer définitivement ce TFC, son fichier PDF et ses commentaires ?')) return;
            const { error } = await supabase.from('tfc').delete().eq('id', id);
            if (error) return toast('Suppression impossible : ' + error.message);
            await supabase.storage.from(BUCKET).remove([bloc.dataset.chemin]);   // le fichier, une fois la ligne supprimée
            charger();
        }
    });

    liste.addEventListener('submit', async (e) => {
        const form = e.target.closest('.form-corriger');
        if (!form) return;
        e.preventDefault();
        const f = new FormData(form);
        const champs = Object.fromEntries(['titre', 'resume', 'mots_cles', 'directeur_recherche', 'annee_academique'].map((c) => [c, String(f.get(c) || '').trim()]));
        const { error } = await supabase.from('tfc').update(champs).eq('id', form.closest('article').dataset.id);
        if (error) return toast('Modification impossible : ' + error.message);
        toast('Informations corrigées.');
        charger();
    });

    charger();
}
