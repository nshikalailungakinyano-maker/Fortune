import { supabase } from './supabaseClient.js';
import { urlAbsolue, connexionOAuth, marquerCompteConnu } from './auth.js';
import { monterEntete } from './layout.js';
import { afficherMessage, traduireErreur, remplirDatalist, MOT_DE_PASSE_MIN } from './utils.js';
import { FACULTES, DEPARTEMENTS, PROMOTIONS } from './listes.js';

const msg = document.getElementById('message');
const form = document.getElementById('formInscription');
const btn = document.getElementById('btnInscription');
const val = (id) => document.getElementById(id).value.trim();

monterEntete('inscription');
remplirDatalist('listeFacultes', FACULTES);
remplirDatalist('listeDepartements', DEPARTEMENTS);
remplirDatalist('listePromotions', PROMOTIONS);

form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const motDePasse = document.getElementById('motDePasse').value;
    if (motDePasse.length < MOT_DE_PASSE_MIN) {
        return afficherMessage(msg, `Le mot de passe doit contenir au moins ${MOT_DE_PASSE_MIN} caractères.`, 'erreur');
    }
    if (motDePasse !== document.getElementById('confirmation').value) {
        return afficherMessage(msg, 'Les deux mots de passe ne correspondent pas.', 'erreur');
    }

    btn.disabled = true;
    afficherMessage(msg, 'Création du compte en cours...', 'info');

    const { data, error } = await supabase.auth.signUp({
        email: val('email'),
        password: motDePasse,
        options: {
            emailRedirectTo: urlAbsolue('connexion.html'),
            // Lues par le trigger SQL qui crée le profil (le rôle est imposé côté serveur)
            data: {
                nom: val('nom'), postnom: val('postnom'), prenom: val('prenom'), sexe: val('sexe'),
                matricule: val('matricule'), faculte: val('faculte'),
                departement: val('departement'), promotion: val('promotion')
            }
        }
    });

    if (error) {
        afficherMessage(msg, traduireErreur(error.message), 'erreur');
        btn.disabled = false;
        return;
    }

    // E-mail déjà utilisé : Supabase renvoie alors un utilisateur sans identité
    if (data.user && data.user.identities && data.user.identities.length === 0) {
        afficherMessage(msg, 'Cet e-mail est déjà utilisé.', 'erreur');
        btn.disabled = false;
        return;
    }

    marquerCompteConnu();
    form.reset();
    if (data.session) {
        afficherMessage(msg, 'Compte créé ! Redirection...', 'ok');
        setTimeout(() => { location.href = 'connexion.html'; }, 1200);
    } else {
        afficherMessage(msg, 'Compte créé ! Un e-mail de confirmation vous a été envoyé : cliquez sur le lien, puis connectez-vous.', 'ok');
    }
    btn.disabled = false;
});

async function lancerOAuth(provider) {
    try { await connexionOAuth(provider); }
    catch (err) { afficherMessage(msg, traduireErreur(err.message), 'erreur'); }
}
document.getElementById('btnGoogle').addEventListener('click', () => lancerOAuth('google'));
document.getElementById('btnMicrosoft').addEventListener('click', () => lancerOAuth('azure'));
