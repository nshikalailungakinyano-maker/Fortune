import { supabase } from './supabaseClient.js';
import { exigerEtudiant } from './auth.js';
import { monterEntete, monterMenuEtudiant } from './layout.js';
import { esc, afficherMessage } from './utils.js';
import { dateRelative, toast } from './tfc-ui.js';

const ctx = await exigerEtudiant();
if (ctx) {
    const moi = ctx.session.user.id;
    const etat = document.getElementById('etat');
    const liste = document.getElementById('liste');
    monterEntete('espace');
    monterMenuEtudiant('mes-commentaires', moi);

    async function charger() {
        const { data, error } = await supabase.from('commentaires')
            .select('*, tfc(id, titre)').eq('etudiant_id', moi)
            .order('date_creation', { ascending: false }).limit(50);
        if (error) return afficherMessage(etat, 'Erreur : ' + error.message, 'erreur');

        afficherMessage(etat, data.length ? '' : "Vous n'avez pas encore commenté de TFC.", 'info');
        liste.innerHTML = data.map((c) => `<article class="carte" data-id="${esc(c.id)}">
            <p class="meta-ligne" style="margin-top:0">Sur ${c.tfc
                ? `<a href="tfc.html?id=${esc(c.tfc.id)}#commentaires">${esc(c.tfc.titre)}</a>` : 'un TFC indisponible'}
                · ${esc(dateRelative(c.date_creation))}${c.est_masque ? ' · <b>masqué par le propriétaire</b>' : ''}</p>
            <div class="com-texte">${esc(c.contenu)}</div>
            <div class="com-meta"><button type="button" data-act="edit">Modifier</button><button type="button" data-act="del">Supprimer</button></div>
        </article>`).join('');
    }

    liste.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-act]');
        if (!b) return;
        const bloc = b.closest('article');
        const idCom = bloc.dataset.id;

        if (b.dataset.act === 'del') {
            if (!confirm('Supprimer ce commentaire ?')) return;
            const { error } = await supabase.from('commentaires').delete().eq('id', idCom);
            if (error) return toast('Suppression impossible : ' + error.message);
            charger();
        } else if (b.dataset.act === 'edit') {
            const zone = bloc.querySelector('.com-texte');
            const ancien = zone.textContent;
            zone.innerHTML = `<textarea rows="3" maxlength="1000"></textarea>
                <div class="com-meta"><button type="button" data-act="save">Enregistrer</button><button type="button" data-act="cancel">Annuler</button></div>`;
            zone.querySelector('textarea').value = ancien;
        } else if (b.dataset.act === 'save') {
            const contenu = bloc.querySelector('textarea').value.trim();
            if (!contenu) return;
            const { error } = await supabase.from('commentaires').update({ contenu }).eq('id', idCom);
            if (error) return toast('Modification impossible : ' + error.message);
            charger();
        } else if (b.dataset.act === 'cancel') {
            charger();
        }
    });

    charger();
}
