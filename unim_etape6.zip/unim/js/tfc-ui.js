// js/tfc-ui.js — données et affichage des publications (TFC) : cartes, likes, partage, téléchargement
import { supabase } from './supabaseClient.js';
import { esc, afficherMessage } from './utils.js';

export const TAILLE_PAGE = 10;
export const BUCKET = 'tfc-documents';

// ---------- Icônes (SVG)
const ICONES = {
    like: '<path d="M7 10v12"/><path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z"/>',
    commentaire: '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
    partage: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/>',
    telecharger: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
    lire: '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
    oeil: '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
    fichier: '<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><line x1="16" x2="8" y1="13" y2="13"/><line x1="16" x2="8" y1="17" y2="17"/><line x1="10" x2="8" y1="9" y2="9"/>'
};
export const icone = (nom, rempli = false, taille = 20) =>
    `<svg viewBox="0 0 24 24" width="${taille}" height="${taille}" fill="${rempli ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONES[nom]}</svg>`;

// ---------- Petits utilitaires
export const estUuid = (v) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v || '');
const nettoyer = (s) => String(s || '').replace(/[,()%*\\"]/g, ' ').trim();   // retire ce qui casse les filtres PostgREST
export const compte = (relation) => relation?.[0]?.count ?? 0;
export const urlTfc = (id) => new URL('tfc.html?id=' + id, location.href).href;

export function nomComplet(a) {
    return [a?.prenom, a?.postnom, a?.nom].filter(Boolean).join(' ') || 'Étudiant UNIM';
}

export function dateRelative(iso) {
    const d = new Date(iso);
    if (isNaN(d)) return '';
    const s = (Date.now() - d.getTime()) / 1000;
    if (s < 60) return "à l'instant";
    if (s < 3600) return `il y a ${Math.floor(s / 60)} min`;
    if (s < 86400) return `il y a ${Math.floor(s / 3600)} h`;
    if (s < 7 * 86400) { const j = Math.floor(s / 86400); return j === 1 ? 'hier' : `il y a ${j} jours`; }
    return d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
}

const COULEURS = ['#0284c7', '#4f46e5', '#0d9488', '#db2777', '#ea580c', '#7c3aed'];

// Photo si l'étudiant en a une, sinon pastille colorée avec ses initiales
export function avatarHtml(a, classe = '') {
    if (a?.photo_url) {
        try {
            const u = new URL(a.photo_url);
            if (u.protocol === 'https:' || u.protocol === 'http:') {
                return `<img class="avatar ${classe}" src="${esc(u.href)}" alt="" loading="lazy">`;
            }
        } catch { /* URL invalide : on affiche les initiales */ }
    }
    const initiales = (((a?.prenom || '')[0] || '') + ((a?.nom || '')[0] || '')).toUpperCase() || 'U';
    const graine = [...String(a?.id || initiales)].reduce((t, c) => t + c.charCodeAt(0), 0);
    return `<span class="avatar ${classe}" style="background:${COULEURS[graine % COULEURS.length]}" aria-hidden="true">${esc(initiales)}</span>`;
}

export function toast(texte, lien) {
    let t = document.getElementById('toast');
    if (!t) {
        t = document.createElement('div');
        t.id = 'toast';
        t.className = 'toast';
        t.setAttribute('role', 'status');
        document.body.appendChild(t);
    }
    t.textContent = texte;
    if (lien) {
        const a = document.createElement('a');
        a.href = lien.href;
        a.textContent = lien.texte;
        t.append(' ', a);
    }
    t.classList.add('visible');
    clearTimeout(t._minuteur);
    t._minuteur = setTimeout(() => t.classList.remove('visible'), 3500);
}

// ---------- Accès aux données
// Auteurs : via la vue publique « auteurs » (nom, faculté, promotion, photo...)
export async function chargerAuteurs(ids) {
    const uniques = [...new Set(ids.filter(Boolean))];
    if (uniques.length === 0) return new Map();
    const { data, error } = await supabase.from('auteurs').select('*').in('id', uniques);
    if (error) {
        console.error('Auteurs :', error.message);
        return new Map();
    }
    return new Map(data.map((a) => [a.id, a]));
}

// Ids des étudiants correspondant à des critères (nom, matricule, faculté...)
async function idsAuteurs(c) {
    let r = supabase.from('auteurs').select('id');
    const t = nettoyer(c.texte);
    if (t) r = r.or(`nom.ilike.%${t}%,postnom.ilike.%${t}%,prenom.ilike.%${t}%`);
    for (const champ of ['matricule', 'faculte', 'departement', 'promotion']) {
        const v = nettoyer(c[champ]);
        if (v) r = r.ilike(champ, `%${v}%`);
    }
    const { data } = await r.limit(500);
    return (data || []).map((a) => a.id);
}

// Recherche simple (q) + recherche avancée (autres champs) + profil d'un étudiant (etudiantId)
export async function chercherTfc(f = {}, page = 0) {
    let req = supabase
        .from('tfc')
        .select('*, likes_tfc(count), commentaires(count)')
        .eq('statut', 'publie')
        .order('date_depot', { ascending: false })
        .range(page * TAILLE_PAGE, page * TAILLE_PAGE + TAILLE_PAGE - 1);

    if (f.etudiantId) req = req.eq('etudiant_id', f.etudiantId);

    const q = nettoyer(f.q);
    if (q) {
        const ids = await idsAuteurs({ texte: q });
        const parties = [`titre.ilike.%${q}%`, `mots_cles.ilike.%${q}%`];
        if (ids.length) parties.push(`etudiant_id.in.(${ids.join(',')})`);
        req = req.or(parties.join(','));
    }
    if (nettoyer(f.titre)) req = req.ilike('titre', `%${nettoyer(f.titre)}%`);
    if (nettoyer(f.motsCles)) req = req.ilike('mots_cles', `%${nettoyer(f.motsCles)}%`);
    if (f.annee) req = req.eq('annee_academique', f.annee);

    const critAuteur = { texte: f.auteur, matricule: f.matricule, faculte: f.faculte, departement: f.departement, promotion: f.promotion };
    if (Object.values(critAuteur).some((v) => nettoyer(v))) {
        const ids = await idsAuteurs(critAuteur);
        if (ids.length === 0) return { tfcs: [], aEncore: false };
        req = req.in('etudiant_id', ids);
    }

    const { data, error } = await req;
    if (error) throw error;
    return { tfcs: data, aEncore: data.length === TAILLE_PAGE };
}

export async function mesLikes(etudiantId, idsTfc) {
    if (!etudiantId || idsTfc.length === 0) return new Set();
    const { data } = await supabase.from('likes_tfc').select('tfc_id').eq('etudiant_id', etudiantId).in('tfc_id', idsTfc);
    return new Set((data || []).map((l) => l.tfc_id));
}

// ---------- Affichage d'une publication
export function carteTfc(tfc, auteur, { aime = false, detail = false } = {}) {
    const id = esc(tfc.id);
    const idA = esc(tfc.etudiant_id);
    const resume = tfc.resume || '';
    const tronque = !detail && resume.length > 220;
    const texteResume = tronque ? resume.slice(0, 220).trimEnd() + '…' : resume;

    const infos = [
        ['Faculté', auteur?.faculte],
        ...(detail ? [['Département', auteur?.departement]] : []),
        ['Promotion', auteur?.promotion],
        ['Directeur', tfc.directeur_recherche],
        ['Année', tfc.annee_academique],
        ...(detail ? [['Matricule', auteur?.matricule]] : [])
    ].filter(([, v]) => v).map(([l, v]) => `<li><b>${l} :</b> ${esc(v)}</li>`).join('');

    const puces = (tfc.mots_cles || '').split(',').map((m) => m.trim()).filter(Boolean)
        .map((m) => `<a href="bibliotheque.html?q=${encodeURIComponent(m)}">${esc(m)}</a>`).join('');

    const badge = tfc.statut && tfc.statut !== 'publie'
        ? `<span class="badge-statut">${tfc.statut === 'masque' ? 'Masqué' : 'Signalé'}</span>` : '';

    return `
<article class="post" data-id="${id}">
  <header class="post-entete">
    <a class="avatar-lien" href="auteur.html?id=${idA}" aria-label="Profil de ${esc(nomComplet(auteur))}">${avatarHtml(auteur)}</a>
    <div class="post-qui">
      <a class="post-nom" href="auteur.html?id=${idA}">${esc(nomComplet(auteur))}</a>
      <div class="post-sous">${esc(dateRelative(tfc.date_depot))} · ${icone('oeil', false, 14)} ${esc(tfc.nombre_vues ?? 0)} vues ${badge}</div>
    </div>
  </header>

  <div class="post-texte">
    <h2 class="post-titre">${detail ? esc(tfc.titre) : `<a href="tfc.html?id=${id}">${esc(tfc.titre)}</a>`}</h2>
    <p class="resume">${esc(texteResume)}${tronque ? ` <a href="tfc.html?id=${id}">voir plus</a>` : ''}</p>
    <ul class="infos">${infos}</ul>
    ${puces ? `<div class="puces">${puces}</div>` : ''}
  </div>

  <div class="media">
    <div class="couverture">
      ${icone('fichier', false, 44)}
      <span class="pdf-badge">PDF</span>
      <div class="couv-titre">${esc(tfc.titre)}</div>
      <div class="couv-sous">Travail de fin de cycle${tfc.annee_academique ? ' · ' + esc(tfc.annee_academique) : ''}</div>
    </div>
    <div class="media-btns">
      <a class="btn" href="lecteur.html?id=${id}">${icone('lire')} Lire</a>
      <button type="button" class="btn btn-contour" data-act="dl" data-chemin="${esc(tfc.fichier_pdf_url)}" data-titre="${esc(tfc.titre)}">${icone('telecharger')} Télécharger</button>
    </div>
  </div>

  <div class="post-actions">
    <button type="button" class="act${aime ? ' actif' : ''}" data-act="like" data-id="${id}" aria-pressed="${aime}">${icone('like', aime)}<span class="n">${compte(tfc.likes_tfc)}</span><span class="lib">J'aime</span></button>
    <a class="act" href="tfc.html?id=${id}#commentaires">${icone('commentaire')}<span class="n n-com">${compte(tfc.commentaires)}</span><span class="lib">Commentaires</span></a>
    <button type="button" class="act" data-act="partage" data-id="${id}" data-titre="${esc(tfc.titre)}">${icone('partage')}<span class="lib">Partager</span></button>
  </div>
</article>`;
}

// ---------- Actions : J'aime, partager, télécharger
async function basculerLike(btn, moi) {
    if (!moi) {
        toast("Connectez-vous pour aimer ce TFC.", { href: 'connexion.html', texte: 'Se connecter' });
        return;
    }
    const idTfc = btn.dataset.id;
    const dejaAime = btn.classList.contains('actif');
    btn.disabled = true;

    const { error } = dejaAime
        ? await supabase.from('likes_tfc').delete().eq('tfc_id', idTfc).eq('etudiant_id', moi)
        : await supabase.from('likes_tfc').insert([{ tfc_id: idTfc, etudiant_id: moi }]);

    if (error && error.code !== '23505') {
        toast("Action impossible : " + error.message);
    } else {
        const maintenantAime = !dejaAime;
        const n = btn.querySelector('.n');
        if (!(error && error.code === '23505')) n.textContent = Math.max(0, Number(n.textContent) + (maintenantAime ? 1 : -1));
        btn.classList.toggle('actif', maintenantAime);
        btn.setAttribute('aria-pressed', String(maintenantAime));
        btn.querySelector('svg').setAttribute('fill', maintenantAime ? 'currentColor' : 'none');
    }
    btn.disabled = false;
}

async function partager(btn) {
    const url = urlTfc(btn.dataset.id);
    const donnees = { title: btn.dataset.titre, text: `Découvrez ce TFC sur UNIM : ${btn.dataset.titre}`, url };
    if (navigator.share) {
        try { await navigator.share(donnees); } catch { /* partage annulé */ }
        return;
    }
    try {
        await navigator.clipboard.writeText(url);
        toast('Lien copié ! Collez-le pour le partager.');
    } catch {
        window.prompt('Copiez ce lien pour le partager :', url);
    }
}

function nomFichier(titre) {
    const base = String(titre || 'TFC').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-zA-Z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 60);
    return (base || 'TFC') + '.pdf';
}

export async function telecharger(chemin, titre) {
    const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(chemin, 60, { download: nomFichier(titre) });
    if (error || !data) {
        toast("Téléchargement impossible pour le moment.");
        return;
    }
    const a = document.createElement('a');
    a.href = data.signedUrl;
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
}

// Un seul écouteur pour toutes les cartes d'un conteneur (fonctionne aussi pour les cartes ajoutées plus tard)
export function brancherActions(racine, moi) {
    racine.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-act]');
        if (!b) return;
        if (b.dataset.act === 'like') await basculerLike(b, moi);
        else if (b.dataset.act === 'partage') await partager(b);
        else if (b.dataset.act === 'dl') {
            b.disabled = true;
            await telecharger(b.dataset.chemin, b.dataset.titre);
            b.disabled = false;
        }
    });
}

// ---------- Fil de publications avec « Voir plus » (bibliothèque et profil d'un étudiant)
export function creerFlux({ flux, etat, btnPlus, moi, obtenirFiltres }) {
    let page = 0;
    let enCours = false;

    async function charger(recommencer) {
        if (enCours) return;
        enCours = true;
        if (recommencer) { page = 0; flux.innerHTML = ''; }
        btnPlus.hidden = true;
        afficherMessage(etat, 'Chargement...', 'info');

        try {
            const { tfcs, aEncore } = await chercherTfc(obtenirFiltres(), page);
            afficherMessage(etat, '', 'info');

            if (page === 0 && tfcs.length === 0) {
                afficherMessage(etat, 'Aucun TFC trouvé.', 'info');
            } else {
                const [auteurs, aimes] = await Promise.all([
                    chargerAuteurs(tfcs.map((t) => t.etudiant_id)),
                    mesLikes(moi, tfcs.map((t) => t.id))
                ]);
                flux.insertAdjacentHTML('beforeend',
                    tfcs.map((t) => carteTfc(t, auteurs.get(t.etudiant_id), { aime: aimes.has(t.id) })).join(''));
                page++;
            }
            btnPlus.hidden = !aEncore;
        } catch (err) {
            console.error('Chargement des TFC :', err);
            afficherMessage(etat, 'Erreur : ' + err.message, 'erreur');
        } finally {
            enCours = false;
        }
    }

    btnPlus.addEventListener('click', () => charger(false));
    brancherActions(flux, moi);
    return { recharger: () => charger(true) };
}
