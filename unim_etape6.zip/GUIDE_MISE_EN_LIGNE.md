# UNIM — Guide de mise en ligne (étape 6)

Les menus de Cloudflare, Google, Microsoft et Supabase changent parfois de nom : si un libellé diffère un peu, cherche l'équivalent.

Ton adresse Supabase (déjà dans le code) : `https://uomuplfhkrjhxbhkcfku.supabase.co`
Adresse de rappel (callback) pour Google et Microsoft : `https://uomuplfhkrjhxbhkcfku.supabase.co/auth/v1/callback`

---------------------------------------------------------------------

## 1. Mettre le site en ligne (Cloudflare Pages)

**Méthode simple (envoi de fichiers)**
1. dashboard.cloudflare.com → **Workers & Pages** → **Create** → onglet **Pages** → **Upload assets**.
2. Nom du projet : par exemple `unim` → le site sera `https://unim.pages.dev`.
3. Glisse le **contenu** du dossier `unim` (pas le dossier lui-même) : `index.html`, `_headers`, `css/`, `js/`… doivent être à la racine.
4. **Deploy site**. Pour une mise à jour : crée un nouveau déploiement et renvoie les fichiers.

**Méthode recommandée plus tard (GitHub)** : un dépôt GitHub connecté à Pages, sans commande de build ; chaque modification envoyée met le site à jour.

Cloudflare conseille désormais Workers pour les nouveaux projets, mais Pages fonctionne toujours et correspond à ton cahier des charges.

## 2. Dire à Supabase quelle est l'adresse du site

Supabase → **Authentication** → **URL Configuration** :
- **Site URL** : `https://unim.pages.dev` (ou ton nom de domaine).
- **Redirect URLs** : ajoute `https://unim.pages.dev/**` et, pour tes tests, `http://localhost:8000/**`.

Sans cela, les liens de confirmation d'e-mail et les connexions Google/Microsoft échouent.

## 3. E-mails (indispensable avant d'ouvrir au public)

L'envoi d'e-mails par défaut de Supabase est très limité (quelques e-mails par heure) : au-delà, les inscriptions et les récupérations de mot de passe se bloquent.
1. Crée un compte chez un service d'envoi (Brevo, Resend, etc. — il y a des offres gratuites).
2. Supabase → **Authentication** → **Emails** → **SMTP Settings** → active le SMTP personnalisé et renseigne les identifiants fournis.
3. Dans **Email Templates**, traduis en français « Confirm signup », « Reset password » et « Change email address ».
4. Vérifie que **Confirm email** est activé (ton cahier exige la vérification) et que la longueur minimale du mot de passe est de **8**.

## 4. Connexion avec Google

1. console.cloud.google.com → crée un projet « UNIM ».
2. **Google Auth Platform** (ou *OAuth consent screen*) : nom de l'application « UNIM », ton e-mail d'assistance, public **Externe**.
3. **Publie l'application** (statut « En production »). Sinon seuls les « utilisateurs de test » pourront se connecter. Avec les seules informations de base (e-mail, profil), aucune vérification Google n'est exigée.
4. **Clients / Credentials** → *Create OAuth client ID* → **Web application** :
   - *Authorized redirect URIs* : l'adresse de rappel Supabase ci-dessus.
5. Copie le **Client ID** et le **Client secret**.
6. Supabase → **Authentication** → **Sign In / Providers** → **Google** : active, colle les deux valeurs, enregistre.

## 5. Connexion avec Microsoft

1. portal.azure.com → **Microsoft Entra ID** → **App registrations** → **New registration**.
2. Nom « UNIM ». *Supported account types* : **comptes de tout annuaire organisationnel et comptes Microsoft personnels** (pour que les adresses Outlook/Hotmail marchent aussi).
3. *Redirect URI* : plateforme **Web** + l'adresse de rappel Supabase.
4. Sur la page de l'application, copie l'**Application (client) ID**.
5. **Certificates & secrets** → *New client secret* → copie la colonne **Value** (pas « Secret ID »). Elle ne s'affiche qu'une fois. Note sa date d'expiration et mets un rappel dans ton calendrier : le jour où elle expire, la connexion Microsoft s'arrête.
6. **Token configuration** → *Add optional claim* → type **ID** → ajoute **email** et, par sécurité, **xms_edov**. Cette dernière permet à Supabase de savoir si Microsoft a réellement vérifié l'adresse e-mail (protection contre l'usurpation de comptes).
7. Supabase → **Authentication** → **Sign In / Providers** → **Azure** : active, colle l'Application ID et le secret. Laisse « Azure Tenant URL » vide (valeur par défaut : tous les comptes Microsoft).

Le code demande déjà l'autorisation `email`.

## 6. Activer la politique de sécurité du contenu (CSP)

Le fichier `_headers` contient une CSP en mode **observation** (`Content-Security-Policy-Report-Only`) : elle ne bloque rien, elle signale seulement.
1. Une fois le site en ligne, ouvre chaque page avec F12 → onglet **Console**.
2. Si aucun message « Content Security Policy » n'apparaît : dans `_headers`, remplace `Content-Security-Policy-Report-Only` par `Content-Security-Policy`, puis renvoie le site. Elle devient active.
3. S'il y en a, copie-moi les messages.

## 7. Tests de sécurité

1. Dans Supabase → SQL Editor, exécute `sql/verif_securite.sql` : **aucune ligne** ne doit s'afficher.
2. Ouvre `/tests-securite.html` **déconnecté**, puis lance les tests : tout doit être ✓.
3. Reconnecte-toi avec un **compte étudiant** (pas le propriétaire) et relance : tout doit être ✓.
4. Si un test affiche ✗ : ne publie pas, envoie-moi la ligne concernée.
5. Quand tout est ✓, **supprime** `tests-securite.html` et `js/tests-securite.js` du site.

## 8. Surveillance (cahier des charges, section 15)

- Les projets Supabase gratuits peuvent être mis en pause après une période sans activité : connecte-toi régulièrement au tableau de bord et vérifie les limites actuelles (base de données, stockage, transfert, e-mails) dans la page d'utilisation.
- Fais une sauvegarde manuelle régulière : export des tables (Table Editor → Export) et téléchargement des PDF (Storage).

## 9. Dépannage rapide

| Symptôme | Cause probable |
|---|---|
| Après la connexion Google/Microsoft, retour sur une erreur | l'adresse du site manque dans *Redirect URLs* (point 2) |
| « redirect_uri_mismatch » | l'adresse de rappel n'est pas celle de Supabase dans Google/Microsoft |
| Google : « accès bloqué » | l'application est encore en mode « Test » (point 4.3) |
| Microsoft : plus de connexion du jour au lendemain | le secret a expiré (point 5.5) |
| Pas d'e-mail de confirmation | limite d'envoi atteinte : configure le SMTP (point 3) |
| Le lecteur PDF reste vide | consulte la console (F12) ; envoie-moi le message |
