-- =====================================================================
-- UNIM — Étape 1 : sécurité et logique de la base (alignée sur le cahier v1.1)
-- Tables : etudiants, tfc, commentaires, likes_tfc, notifications, journal_activites
--
-- À exécuter UNE seule fois dans Supabase > SQL Editor.
-- Le script est « tout ou rien » : en cas d'erreur, rien n'est modifié.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 0. AJUSTEMENTS DE STRUCTURE
-- ---------------------------------------------------------------------

-- Supabase Auth stocke déjà le mot de passe haché (bcrypt) dans auth.users.
-- Une 2e copie dans nos tables n'apporte aucune sécurité et ajoute un risque.
alter table public.etudiants drop column if exists mot_de_passe;

-- Les comptes Google/Microsoft n'ont pas de matricule/faculté/etc. à l'inscription :
-- ces champs sont complétés ensuite par l'étudiant (le matricule reste unique).
alter table public.etudiants alter column matricule   drop not null;
alter table public.etudiants alter column faculte     drop not null;
alter table public.etudiants alter column departement drop not null;
alter table public.etudiants alter column promotion   drop not null;

-- Longueur d'un commentaire : 1 à 1000 caractères
alter table public.commentaires drop constraint if exists commentaires_contenu_longueur;
alter table public.commentaires
  add constraint commentaires_contenu_longueur
  check (char_length(btrim(contenu)) between 1 and 1000);

-- Index (les clés étrangères n'en ont pas automatiquement)
create index if not exists idx_tfc_etudiant          on public.tfc (etudiant_id);
create index if not exists idx_tfc_statut_date       on public.tfc (statut, date_depot desc);
create index if not exists idx_commentaires_tfc      on public.commentaires (tfc_id);
create index if not exists idx_commentaires_etudiant on public.commentaires (etudiant_id);
create index if not exists idx_notifications_etud    on public.notifications (etudiant_id, est_lu);
create index if not exists idx_journal_date          on public.journal_activites (date_creation desc);


-- ---------------------------------------------------------------------
-- 1. FONCTIONS UTILITAIRES
-- ---------------------------------------------------------------------

-- L'utilisateur connecté est-il le propriétaire (actif) ?
create or replace function public.est_proprietaire()
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.etudiants
    where id = auth.uid() and role = 'proprietaire' and coalesce(est_actif, true)
  );
$$;

-- L'utilisateur connecté est-il un étudiant actif ?
create or replace function public.est_actif_courant()
returns boolean
language sql stable security definer set search_path = public
as $$
  select coalesce((select est_actif from public.etudiants where id = auth.uid()), false);
$$;

-- Écriture dans le journal privé (interne : jamais appelable depuis le navigateur)
create or replace function public.journaliser(
  p_acteur uuid, p_action text, p_cible_type text, p_details text default null)
returns void
language sql security definer set search_path = public
as $$
  insert into public.journal_activites (acteur_id, action, cible_type, details)
  values (p_acteur, p_action, p_cible_type, p_details);
$$;
revoke execute on function public.journaliser(uuid, text, text, text) from public, anon, authenticated;

-- Création d'une notification (interne)
create or replace function public.notifier(p_etudiant uuid, p_type text, p_message text)
returns void
language sql security definer set search_path = public
as $$
  insert into public.notifications (etudiant_id, type, message)
  values (p_etudiant, p_type, p_message);
$$;
revoke execute on function public.notifier(uuid, text, text) from public, anon, authenticated;

-- Mise à jour automatique de date_modification
create or replace function public.maj_date_modification()
returns trigger
language plpgsql
as $$
begin
  new.date_modification := timezone('utc'::text, now());
  return new;
end;
$$;


-- ---------------------------------------------------------------------
-- 2. CRÉATION AUTOMATIQUE DU PROFIL À L'INSCRIPTION
--    (e-mail/mot de passe, Google ou Microsoft)
--    Le rôle est imposé ici : impossible à falsifier depuis le navigateur.
-- ---------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql security definer set search_path = public
as $$
declare
  m jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
begin
  insert into public.etudiants
    (id, nom, postnom, prenom, sexe, email, matricule, faculte, departement, promotion, role, est_actif)
  values (
    new.id,
    coalesce(nullif(btrim(m->>'nom'), ''), nullif(btrim(m->>'family_name'), ''),
             nullif(btrim(m->>'full_name'), ''), nullif(btrim(m->>'name'), ''), 'À compléter'),
    nullif(btrim(m->>'postnom'), ''),
    coalesce(nullif(btrim(m->>'prenom'), ''), nullif(btrim(m->>'given_name'), ''), 'À compléter'),
    nullif(btrim(m->>'sexe'), ''),
    new.email,
    nullif(btrim(m->>'matricule'), ''),
    nullif(btrim(m->>'faculte'), ''),
    nullif(btrim(m->>'departement'), ''),
    nullif(btrim(m->>'promotion'), ''),
    'etudiant',
    true
  );

  perform public.journaliser(new.id, 'creation_compte', 'etudiant', 'etudiant_id=' || new.id::text);
  return new;
end;
$$;
revoke execute on function public.handle_new_user() from public, anon, authenticated;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

drop trigger if exists trg_etudiants_modif on public.etudiants;
create trigger trg_etudiants_modif
  before update on public.etudiants
  for each row execute function public.maj_date_modification();


-- ---------------------------------------------------------------------
-- 3. TRIGGERS : JOURNAL PRIVÉ ET NOTIFICATIONS
--    (le nombre de vues n'active volontairement AUCUN de ces triggers)
-- ---------------------------------------------------------------------

-- TFC : dépôt, publication automatique, suppression
create or replace function public.trg_tfc_depot_suppression()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  if tg_op = 'INSERT' then
    perform public.journaliser(auth.uid(), 'depot_tfc', 'tfc', 'tfc_id=' || new.id::text);
    if new.statut = 'publie' then
      perform public.journaliser(auth.uid(), 'publication_automatique', 'tfc', 'tfc_id=' || new.id::text);
    end if;
  elsif tg_op = 'DELETE' then
    perform public.journaliser(auth.uid(), 'suppression_tfc', 'tfc', 'tfc_id=' || old.id::text);
  end if;
  return null;
end;
$$;
revoke execute on function public.trg_tfc_depot_suppression() from public, anon, authenticated;

drop trigger if exists trg_tfc_depot_suppression on public.tfc;
create trigger trg_tfc_depot_suppression
  after insert or delete on public.tfc
  for each row execute function public.trg_tfc_depot_suppression();

-- TFC : changement de statut (masquage, republication, signalement) + notification à l'auteur
create or replace function public.trg_tfc_statut()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  perform public.journaliser(
    auth.uid(),
    case new.statut when 'masque' then 'masquage_tfc'
                    when 'publie' then 'republication_tfc'
                    else 'signalement_tfc' end,
    'tfc', 'tfc_id=' || new.id::text);

  perform public.notifier(
    new.etudiant_id, 'statut_tfc',
    case new.statut when 'masque' then 'Votre TFC a été masqué par le propriétaire.'
                    when 'publie' then 'Votre TFC est de nouveau publié.'
                    else 'Votre TFC a été signalé.' end);
  return null;
end;
$$;
revoke execute on function public.trg_tfc_statut() from public, anon, authenticated;

drop trigger if exists trg_tfc_statut on public.tfc;
create trigger trg_tfc_statut
  after update of statut on public.tfc
  for each row when (old.statut is distinct from new.statut)
  execute function public.trg_tfc_statut();

-- TFC : correction des informations
create or replace function public.trg_tfc_modification()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  perform public.journaliser(auth.uid(), 'modification_tfc', 'tfc', 'tfc_id=' || new.id::text);
  return null;
end;
$$;
revoke execute on function public.trg_tfc_modification() from public, anon, authenticated;

drop trigger if exists trg_tfc_modification on public.tfc;
create trigger trg_tfc_modification
  after update of titre, resume, mots_cles, directeur_recherche, annee_academique on public.tfc
  for each row
  when (old.titre is distinct from new.titre
     or old.resume is distinct from new.resume
     or old.mots_cles is distinct from new.mots_cles
     or old.directeur_recherche is distinct from new.directeur_recherche
     or old.annee_academique is distinct from new.annee_academique)
  execute function public.trg_tfc_modification();

drop trigger if exists trg_tfc_modif_date on public.tfc;
create trigger trg_tfc_modif_date
  before update of titre, resume, mots_cles, directeur_recherche, annee_academique, statut on public.tfc
  for each row execute function public.maj_date_modification();

-- Commentaires : notification lors d'une réponse
create or replace function public.trg_commentaire_reponse()
returns trigger
language plpgsql security definer set search_path = public
as $$
declare
  v_auteur uuid;
begin
  if new.parent_id is not null then
    select etudiant_id into v_auteur from public.commentaires where id = new.parent_id;
    if v_auteur is not null and v_auteur <> new.etudiant_id then
      perform public.notifier(v_auteur, 'reponse_commentaire', 'Un étudiant a répondu à votre commentaire.');
    end if;
  end if;
  return null;
end;
$$;
revoke execute on function public.trg_commentaire_reponse() from public, anon, authenticated;

drop trigger if exists trg_commentaire_reponse on public.commentaires;
create trigger trg_commentaire_reponse
  after insert on public.commentaires
  for each row execute function public.trg_commentaire_reponse();

-- Commentaires : modération (masquage / démasquage)
create or replace function public.trg_commentaire_moderation()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  perform public.journaliser(
    auth.uid(),
    case when new.est_masque then 'masquage_commentaire' else 'demasquage_commentaire' end,
    'commentaire', 'commentaire_id=' || new.id::text);
  return null;
end;
$$;
revoke execute on function public.trg_commentaire_moderation() from public, anon, authenticated;

drop trigger if exists trg_commentaire_moderation on public.commentaires;
create trigger trg_commentaire_moderation
  after update of est_masque on public.commentaires
  for each row when (old.est_masque is distinct from new.est_masque)
  execute function public.trg_commentaire_moderation();

-- Commentaires : suppression par le propriétaire (modération)
create or replace function public.trg_commentaire_suppression()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  if old.etudiant_id is distinct from auth.uid() and public.est_proprietaire() then
    perform public.journaliser(auth.uid(), 'suppression_commentaire', 'commentaire', 'commentaire_id=' || old.id::text);
  end if;
  return null;
end;
$$;
revoke execute on function public.trg_commentaire_suppression() from public, anon, authenticated;

drop trigger if exists trg_commentaire_suppression on public.commentaires;
create trigger trg_commentaire_suppression
  after delete on public.commentaires
  for each row execute function public.trg_commentaire_suppression();


-- ---------------------------------------------------------------------
-- 4. FONCTIONS APPELABLES DEPUIS L'APPLICATION (RPC)
-- ---------------------------------------------------------------------

-- Compteur de vues : seul moyen d'augmenter nombre_vues (aucun étudiant ne peut modifier un TFC)
create or replace function public.incrementer_vues(p_tfc_id uuid)
returns void
language sql security definer set search_path = public
as $$
  update public.tfc set nombre_vues = nombre_vues + 1
  where id = p_tfc_id and statut = 'publie';
$$;
grant execute on function public.incrementer_vues(uuid) to anon, authenticated;

-- Journal : connexion / déconnexion uniquement (limité à 1 événement / 30 s pour éviter le spam)
create or replace function public.journaliser_evenement(p_action text)
returns void
language plpgsql security definer set search_path = public
as $$
begin
  if auth.uid() is null then return; end if;
  if p_action not in ('connexion', 'deconnexion') then
    raise exception 'Action non autorisée';
  end if;
  if exists (
    select 1 from public.journal_activites
    where acteur_id = auth.uid() and action = p_action
      and date_creation > now() - interval '30 seconds'
  ) then
    return;
  end if;
  perform public.journaliser(auth.uid(), p_action, 'session', null);
end;
$$;
revoke execute on function public.journaliser_evenement(text) from public, anon;
grant  execute on function public.journaliser_evenement(text) to authenticated;

-- Propriétaire : suspendre / réactiver un compte étudiant
create or replace function public.proprietaire_definir_actif(p_etudiant uuid, p_actif boolean)
returns void
language plpgsql security definer set search_path = public
as $$
begin
  if not public.est_proprietaire() then
    raise exception 'Accès refusé';
  end if;
  if p_etudiant = auth.uid() then
    raise exception 'Vous ne pouvez pas modifier votre propre statut';
  end if;

  update public.etudiants set est_actif = p_actif where id = p_etudiant;

  perform public.journaliser(
    auth.uid(),
    case when p_actif then 'reactivation_compte' else 'suspension_compte' end,
    'etudiant', 'etudiant_id=' || p_etudiant::text);

  perform public.notifier(
    p_etudiant, 'compte',
    case when p_actif then 'Votre compte a été réactivé.' else 'Votre compte a été suspendu.' end);
end;
$$;
revoke execute on function public.proprietaire_definir_actif(uuid, boolean) from public, anon;
grant  execute on function public.proprietaire_definir_actif(uuid, boolean) to authenticated;

-- Propriétaire : masquer / démasquer un commentaire
create or replace function public.proprietaire_masquer_commentaire(p_commentaire uuid, p_masque boolean)
returns void
language plpgsql security definer set search_path = public
as $$
begin
  if not public.est_proprietaire() then
    raise exception 'Accès refusé';
  end if;
  update public.commentaires set est_masque = p_masque where id = p_commentaire;
end;
$$;
revoke execute on function public.proprietaire_masquer_commentaire(uuid, boolean) from public, anon;
grant  execute on function public.proprietaire_masquer_commentaire(uuid, boolean) to authenticated;


-- ---------------------------------------------------------------------
-- 5. VUE PUBLIQUE DES AUTEURS
--    La table etudiants n'est plus lisible publiquement (e-mail, etc.).
--    Cette vue n'expose que ce que la fiche d'un TFC doit afficher, et seulement
--    pour les étudiants qui ont un TFC publié ou un commentaire visible.
--    NB : le matricule est inclus car le cahier le prévoit dans la fiche TFC et la
--    recherche avancée. Retire la colonne ci-dessous si tu ne veux pas l'afficher.
-- ---------------------------------------------------------------------
create or replace view public.auteurs as
  select id, nom, postnom, prenom, matricule, faculte, departement, promotion
  from public.etudiants
  where id in (select etudiant_id from public.tfc where statut = 'publie')
     or id in (select etudiant_id from public.commentaires where coalesce(est_masque, false) = false);


-- ---------------------------------------------------------------------
-- 6. PRIVILÈGES (en plus du RLS) : qui peut écrire dans quelles colonnes
-- ---------------------------------------------------------------------
revoke insert, update, delete on all tables in schema public from anon;

-- etudiants : aucune création/suppression côté navigateur ; l'étudiant ne modifie que son profil
revoke insert, update, delete on public.etudiants from authenticated;
grant  update (nom, postnom, prenom, sexe, matricule, faculte, departement, promotion)
  on public.etudiants to authenticated;

-- tfc : la modification est réservée au propriétaire (policy) et limitée à ces colonnes
revoke update on public.tfc from authenticated;
grant  update (titre, resume, mots_cles, directeur_recherche, annee_academique, statut)
  on public.tfc to authenticated;

-- commentaires : l'auteur ne modifie que le texte (la modération passe par la fonction dédiée)
revoke update on public.commentaires from authenticated;
grant  update (contenu) on public.commentaires to authenticated;

-- likes : on ajoute ou on retire, on ne modifie pas
revoke update on public.likes_tfc from authenticated;

-- notifications : créées uniquement par le système ; l'étudiant marque « lu » ou supprime
revoke insert, update, delete on public.notifications from authenticated;
grant  update (est_lu) on public.notifications to authenticated;
grant  delete on public.notifications to authenticated;

-- journal : lecture seule pour le propriétaire (policy) ; jamais d'écriture directe
revoke all on public.journal_activites from anon;
revoke insert, update, delete on public.journal_activites from authenticated;

grant select on public.auteurs to anon, authenticated;


-- ---------------------------------------------------------------------
-- 7. POLICIES RLS (on repart de zéro sur les 6 tables)
-- ---------------------------------------------------------------------
do $$
declare r record;
begin
  for r in
    select policyname, tablename from pg_policies
    where schemaname = 'public'
      and tablename in ('etudiants', 'tfc', 'commentaires', 'likes_tfc', 'notifications', 'journal_activites')
  loop
    execute format('drop policy %I on public.%I', r.policyname, r.tablename);
  end loop;
end $$;

alter table public.etudiants         enable row level security;
alter table public.tfc               enable row level security;
alter table public.commentaires      enable row level security;
alter table public.likes_tfc         enable row level security;
alter table public.notifications     enable row level security;
alter table public.journal_activites enable row level security;

-- etudiants
create policy etudiants_lecture on public.etudiants
  for select to authenticated
  using (id = auth.uid() or public.est_proprietaire());

create policy etudiants_maj_perso on public.etudiants
  for update to authenticated
  using (id = auth.uid() and coalesce(est_actif, true))
  with check (id = auth.uid());

-- tfc
create policy tfc_lecture on public.tfc
  for select to anon, authenticated
  using (statut = 'publie' or etudiant_id = auth.uid() or public.est_proprietaire());

create policy tfc_insertion on public.tfc
  for insert to authenticated
  with check (etudiant_id = auth.uid() and public.est_actif_courant()
              and statut = 'publie' and nombre_vues = 0);

create policy tfc_maj_proprietaire on public.tfc
  for update to authenticated
  using (public.est_proprietaire()) with check (public.est_proprietaire());

create policy tfc_suppression_proprietaire on public.tfc
  for delete to authenticated
  using (public.est_proprietaire());

-- commentaires (visibles seulement si le TFC l'est ; les masqués seulement pour leur auteur et le propriétaire)
create policy commentaires_lecture on public.commentaires
  for select to anon, authenticated
  using (
    (coalesce(est_masque, false) = false or etudiant_id = auth.uid() or public.est_proprietaire())
    and exists (select 1 from public.tfc t where t.id = commentaires.tfc_id)
  );

create policy commentaires_insertion on public.commentaires
  for insert to authenticated
  with check (
    etudiant_id = auth.uid() and public.est_actif_courant()
    and coalesce(est_masque, false) = false
    and exists (select 1 from public.tfc t where t.id = tfc_id and t.statut = 'publie')
  );

create policy commentaires_maj_perso on public.commentaires
  for update to authenticated
  using (etudiant_id = auth.uid() and public.est_actif_courant())
  with check (etudiant_id = auth.uid());

create policy commentaires_suppression on public.commentaires
  for delete to authenticated
  using (etudiant_id = auth.uid() or public.est_proprietaire());

-- likes_tfc (les totaux sont visibles par tous)
create policy likes_lecture on public.likes_tfc
  for select to anon, authenticated
  using (true);

create policy likes_insertion on public.likes_tfc
  for insert to authenticated
  with check (
    etudiant_id = auth.uid() and public.est_actif_courant()
    and exists (select 1 from public.tfc t where t.id = tfc_id and t.statut = 'publie')
  );

create policy likes_suppression_perso on public.likes_tfc
  for delete to authenticated
  using (etudiant_id = auth.uid());

-- notifications
create policy notifications_lecture_perso on public.notifications
  for select to authenticated using (etudiant_id = auth.uid());

create policy notifications_maj_perso on public.notifications
  for update to authenticated
  using (etudiant_id = auth.uid()) with check (etudiant_id = auth.uid());

create policy notifications_suppression_perso on public.notifications
  for delete to authenticated using (etudiant_id = auth.uid());

-- journal_activites : lecture réservée au propriétaire, aucune écriture directe
create policy journal_lecture_proprietaire on public.journal_activites
  for select to authenticated
  using (public.est_proprietaire());


-- ---------------------------------------------------------------------
-- 8. STORAGE : bucket privé « tfc-documents »
--    PDF non publiés ou masqués = jamais accessibles aux autres.
--    L'application doit enregistrer dans tfc.fichier_pdf_url le CHEMIN du fichier
--    (ex. <id_étudiant>/1735000000000.pdf) et générer des liens signés pour la lecture.
-- ---------------------------------------------------------------------
update storage.buckets
   set public = false,
       file_size_limit = 20971520,                       -- 20 Mo
       allowed_mime_types = array['application/pdf']
 where id = 'tfc-documents';

drop policy if exists "Autoriser lecture publique PDF" on storage.objects;
drop policy if exists "Autoriser upload PDF"           on storage.objects;
drop policy if exists "tfc_docs_lecture"               on storage.objects;
drop policy if exists "tfc_docs_depot"                 on storage.objects;
drop policy if exists "tfc_docs_suppression"           on storage.objects;

create policy "tfc_docs_lecture" on storage.objects
  for select to anon, authenticated
  using (
    bucket_id = 'tfc-documents'
    and (
      exists (select 1 from public.tfc t where t.fichier_pdf_url = name and t.statut = 'publie')
      or (storage.foldername(name))[1] = auth.uid()::text
      or public.est_proprietaire()
    )
  );

create policy "tfc_docs_depot" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'tfc-documents'
    and (storage.foldername(name))[1] = auth.uid()::text
    and public.est_actif_courant()
  );

create policy "tfc_docs_suppression" on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'tfc-documents'
    and ((storage.foldername(name))[1] = auth.uid()::text or public.est_proprietaire())
  );


-- ---------------------------------------------------------------------
-- 9. TON COMPTE PROPRIÉTAIRE
--    1) Inscris-toi normalement dans l'application avec ton e-mail.
--    2) Puis exécute ceci (en remplaçant l'e-mail), une seule fois :
-- ---------------------------------------------------------------------
-- update public.etudiants set role = 'proprietaire' where email = 'TON_EMAIL@exemple.com';
