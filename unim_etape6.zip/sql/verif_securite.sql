-- =====================================================================
-- UNIM — Contrôle de la configuration de sécurité
-- À exécuter dans Supabase > SQL Editor. RÉSULTAT ATTENDU : aucune ligne.
-- Chaque ligne affichée est un point à corriger.
-- =====================================================================
select 'RLS désactivé sur la table' as probleme, c.relname::text as objet
from pg_class c
join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity

union all
select 'Bucket public (seul « avatars » doit l''être)', id
from storage.buckets
where public and id <> 'avatars'

union all
select 'Fonction SECURITY DEFINER sans search_path fixé', p.proname::text
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.prosecdef and p.proname <> 'rls_auto_enable'
  and not exists (select 1 from unnest(coalesce(p.proconfig, '{}'::text[])) c where c like 'search_path=%')

union all
select 'Le rôle anon peut écrire', table_name || ' (' || privilege_type || ')'
from information_schema.role_table_grants
where grantee = 'anon' and table_schema = 'public'
  and privilege_type in ('INSERT', 'UPDATE', 'DELETE')

union all
select 'Table sans aucune policy (inaccessible)', c.relname::text
from pg_class c
join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public' and c.relkind = 'r' and c.relrowsecurity
  and not exists (select 1 from pg_policies p where p.schemaname = 'public' and p.tablename = c.relname);
