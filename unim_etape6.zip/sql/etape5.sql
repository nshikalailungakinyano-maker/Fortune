-- =====================================================================
-- UNIM — Étape 5 : signalements (espace propriétaire)
-- À exécuter dans Supabase > SQL Editor, après les étapes 1, 3 et 4.
--
-- Principe : pas de 7e table. Un signalement est écrit dans le journal privé
-- (lisible par le seul propriétaire). Le TFC reste visible tant que le propriétaire
-- ne décide pas de le masquer : aucun étudiant ne peut donc retirer un TFC à lui seul.
-- =====================================================================

-- Un étudiant actif signale un TFC publié (1 signalement par TFC et par étudiant, sur 30 jours)
create or replace function public.signaler_tfc(p_tfc uuid, p_motif text default null)
returns void
language plpgsql security definer set search_path = public
as $$
declare
  v_motif text := left(regexp_replace(coalesce(btrim(p_motif), ''), '[\r\n|]+', ' ', 'g'), 200);
begin
  if auth.uid() is null or not public.est_actif_courant() then
    raise exception 'Accès refusé';
  end if;
  if not exists (select 1 from public.tfc where id = p_tfc and statut = 'publie') then
    raise exception 'TFC introuvable';
  end if;
  if exists (
    select 1 from public.journal_activites
    where acteur_id = auth.uid() and action = 'signalement_recu'
      and details like 'tfc_id=' || p_tfc::text || '|%'
      and date_creation > now() - interval '30 days'
  ) then
    return;
  end if;

  perform public.journaliser(auth.uid(), 'signalement_recu', 'tfc',
                             'tfc_id=' || p_tfc::text || '|motif=' || v_motif);
end;
$$;
revoke execute on function public.signaler_tfc(uuid, text) from public, anon;
grant  execute on function public.signaler_tfc(uuid, text) to authenticated;

-- Le propriétaire a examiné les signalements d'un TFC
create or replace function public.proprietaire_traiter_signalements(p_tfc uuid)
returns void
language plpgsql security definer set search_path = public
as $$
begin
  if not public.est_proprietaire() then
    raise exception 'Accès refusé';
  end if;
  perform public.journaliser(auth.uid(), 'signalements_traites', 'tfc', 'tfc_id=' || p_tfc::text);
end;
$$;
revoke execute on function public.proprietaire_traiter_signalements(uuid) from public, anon;
grant  execute on function public.proprietaire_traiter_signalements(uuid) to authenticated;

-- Signalements en attente, par TFC. security_invoker : la vue obéit au RLS du journal,
-- donc tout autre rôle que le propriétaire obtient une liste vide.
create or replace view public.signalements_ouverts with (security_invoker = true) as
with recus as (
  select substring(details from 'tfc_id=([0-9a-f-]{36})')::uuid as tfc_id,
         substring(details from 'motif=(.*)$') as motif,
         date_creation
  from public.journal_activites
  where action = 'signalement_recu'
), traites as (
  select substring(details from 'tfc_id=([0-9a-f-]{36})')::uuid as tfc_id,
         max(date_creation) as traite_le
  from public.journal_activites
  where action = 'signalements_traites'
  group by 1
)
select r.tfc_id,
       count(*)::int as nb,
       max(r.date_creation) as dernier,
       array_agg(r.motif order by r.date_creation) as motifs
from recus r
left join traites t on t.tfc_id = r.tfc_id
where r.date_creation > coalesce(t.traite_le, '-infinity'::timestamptz)
group by r.tfc_id;

revoke all on public.signalements_ouverts from anon;
grant select on public.signalements_ouverts to authenticated;
