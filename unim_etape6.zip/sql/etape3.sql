-- =====================================================================
-- UNIM — Étape 3 : photo de profil + vue des auteurs
-- À exécuter dans Supabase > SQL Editor APRÈS le script de l'étape 1.
-- =====================================================================

-- 1. Photo de profil (colonne facultative ; sans photo, l'application affiche les initiales)
alter table public.etudiants add column if not exists photo_url text;
grant update (photo_url) on public.etudiants to authenticated;

-- 2. La vue publique des auteurs expose aussi la photo
create or replace view public.auteurs as
  select id, nom, postnom, prenom, matricule, faculte, departement, promotion, photo_url
  from public.etudiants
  where id in (select etudiant_id from public.tfc where statut = 'publie')
     or id in (select etudiant_id from public.commentaires where coalesce(est_masque, false) = false);

grant select on public.auteurs to anon, authenticated;

-- 3. Bucket public « avatars » (images seulement, 2 Mo max, un dossier par étudiant)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars', 'avatars', true, 2097152, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update
  set public = true,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "avatars_lecture_perso" on storage.objects;
drop policy if exists "avatars_depot"         on storage.objects;
drop policy if exists "avatars_maj"           on storage.objects;
drop policy if exists "avatars_suppression"   on storage.objects;

create policy "avatars_lecture_perso" on storage.objects
  for select to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "avatars_depot" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text
              and public.est_actif_courant());

create policy "avatars_maj" on storage.objects
  for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "avatars_suppression" on storage.objects
  for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

-- =====================================================================
-- TEST (en attendant l'étape 4 « Déposer un TFC »)
-- 1) Supabase > Storage > tfc-documents : crée un dossier portant TON id
--    (Table Editor > etudiants > colonne id) et mets-y un PDF, par exemple test.pdf
-- 2) Décommente puis exécute, en remplaçant TON_ID :
-- =====================================================================
-- insert into public.tfc
--   (etudiant_id, titre, resume, mots_cles, directeur_recherche, annee_academique, fichier_pdf_url)
-- values
--   ('TON_ID', 'Titre de test', 'Résumé de test : quelques lignes pour vérifier l''affichage.',
--    'test, unim', 'Prof. Exemple', '2025-2026', 'TON_ID/test.pdf');
