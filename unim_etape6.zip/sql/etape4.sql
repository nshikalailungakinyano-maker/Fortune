-- =====================================================================
-- UNIM — Étape 4 : sécurité des comptes (cahier des charges, section 6.4)
-- À exécuter dans Supabase > SQL Editor, APRÈS les scripts des étapes 1 et 3.
-- =====================================================================

-- Quand l'e-mail ou le mot de passe change dans Supabase Auth :
--  - l'e-mail est recopié dans la table etudiants (il n'y était mis qu'à l'inscription)
--  - l'étudiant reçoit une notification de sécurité
create or replace function public.sync_compte_auth()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  if new.email is distinct from old.email then
    update public.etudiants set email = new.email where id = new.id;
    perform public.notifier(new.id, 'securite', 'L''adresse e-mail de votre compte a été modifiée.');
  end if;

  if new.encrypted_password is distinct from old.encrypted_password then
    perform public.notifier(new.id, 'securite', 'Votre mot de passe a été modifié.');
  end if;

  return null;
end;
$$;
revoke execute on function public.sync_compte_auth() from public, anon, authenticated;

drop trigger if exists on_auth_user_updated on auth.users;
create trigger on_auth_user_updated
  after update of email, encrypted_password on auth.users
  for each row execute function public.sync_compte_auth();
